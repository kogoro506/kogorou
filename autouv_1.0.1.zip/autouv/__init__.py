# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "AutoUV",
    "author" : "Pamir Bal", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os


addon_keymaps = {}
_icons = None


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


class SNA_OT_Autouv_Cfcfc(bpy.types.Operator):
    bl_idname = "sna.autouv_cfcfc"
    bl_label = "autouv"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if property_exists("bpy.context.view_layer.objects.active.data.attributes['UVMap']", globals(), locals()):
            bpy.ops.mesh.uv_texture_remove()
        bpy.ops.object.editmode_toggle('INVOKE_DEFAULT', )
        bpy.ops.mesh.select_all('INVOKE_DEFAULT', action='SELECT')
        print(str(bpy.context.scene.sna_angle))
        bpy.ops.uv.smart_project(island_margin=0.019999999552965164, correct_aspect=True)
        bpy.ops.uv.pack_islands(rotate=True, rotate_method='AXIS_ALIGNED', margin_method='ADD', shape_method='CONCAVE')
        bpy.ops.object.editmode_toggle()
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reset_7777F(bpy.types.Operator):
    bl_idname = "sna.reset_7777f"
    bl_label = "reset"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.editmode_toggle('INVOKE_DEFAULT', )
        bpy.ops.mesh.select_all('INVOKE_DEFAULT', action='SELECT')
        bpy.ops.uv.reset('INVOKE_DEFAULT', )
        bpy.ops.object.editmode_toggle()
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Remove_5D366(bpy.types.Operator):
    bl_idname = "sna.remove_5d366"
    bl_label = "remove"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.mesh.uv_texture_remove('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_AUTOUV_52FC0(bpy.types.Panel):
    bl_label = 'AutoUV'
    bl_idname = 'SNA_PT_AUTOUV_52FC0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AutoUV'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.template_icon(icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'autouv.png')), scale=6.909999847412109)
        row_D6D35 = layout.row(heading='', align=False)
        row_D6D35.alert = False
        row_D6D35.enabled = True
        row_D6D35.active = True
        row_D6D35.use_property_split = False
        row_D6D35.use_property_decorate = False
        row_D6D35.scale_x = 3.0
        row_D6D35.scale_y = 3.0
        row_D6D35.alignment = 'Expand'.upper()
        row_D6D35.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_D6D35.operator('sna.autouv_cfcfc', text='AutoUV', icon_value=0, emboss=True, depress=False)
        col_BD500 = layout.column(heading='', align=False)
        col_BD500.alert = False
        col_BD500.enabled = True
        col_BD500.active = True
        col_BD500.use_property_split = False
        col_BD500.use_property_decorate = False
        col_BD500.scale_x = 1.0
        col_BD500.scale_y = 1.0
        col_BD500.alignment = 'Expand'.upper()
        col_BD500.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_5FEE6 = col_BD500.row(heading='', align=False)
        row_5FEE6.alert = False
        row_5FEE6.enabled = True
        row_5FEE6.active = True
        row_5FEE6.use_property_split = False
        row_5FEE6.use_property_decorate = False
        row_5FEE6.scale_x = 3.0
        row_5FEE6.scale_y = 3.0
        row_5FEE6.alignment = 'Expand'.upper()
        row_5FEE6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_5FEE6.operator('sna.reset_7777f', text='Reset UV', icon_value=0, emboss=True, depress=False)
        op = row_5FEE6.operator('sna.remove_5d366', text='Remove UV', icon_value=0, emboss=True, depress=False)


class SNA_PT_DEVELOPER_1A58B(bpy.types.Panel):
    bl_label = 'Developer'
    bl_idname = 'SNA_PT_DEVELOPER_1A58B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_parent_id = 'SNA_PT_AUTOUV_52FC0'
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_A9540 = layout.column(heading='', align=False)
        col_A9540.alert = False
        col_A9540.enabled = True
        col_A9540.active = True
        col_A9540.use_property_split = False
        col_A9540.use_property_decorate = False
        col_A9540.scale_x = 1.0
        col_A9540.scale_y = 1.0
        col_A9540.alignment = 'Expand'.upper()
        col_A9540.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_8D1F6 = col_A9540.row(heading='', align=False)
        row_8D1F6.alert = False
        row_8D1F6.enabled = True
        row_8D1F6.active = True
        row_8D1F6.use_property_split = False
        row_8D1F6.use_property_decorate = False
        row_8D1F6.scale_x = 2.0
        row_8D1F6.scale_y = 2.0
        row_8D1F6.alignment = 'Expand'.upper()
        row_8D1F6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_8D1F6.template_icon(icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'blendermarket.png')), scale=1.0)
        op = row_8D1F6.operator('wm.url_open', text='Visit Shop', icon_value=0, emboss=True, depress=False)
        op.url = 'https://blendermarket.com/creators/pamir-bal'


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_angle = bpy.props.IntProperty(name='Angle', description='', default=0, subtype='NONE')
    bpy.utils.register_class(SNA_OT_Autouv_Cfcfc)
    bpy.utils.register_class(SNA_OT_Reset_7777F)
    bpy.utils.register_class(SNA_OT_Remove_5D366)
    bpy.utils.register_class(SNA_PT_AUTOUV_52FC0)
    bpy.utils.register_class(SNA_PT_DEVELOPER_1A58B)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_angle
    bpy.utils.unregister_class(SNA_OT_Autouv_Cfcfc)
    bpy.utils.unregister_class(SNA_OT_Reset_7777F)
    bpy.utils.unregister_class(SNA_OT_Remove_5D366)
    bpy.utils.unregister_class(SNA_PT_AUTOUV_52FC0)
    bpy.utils.unregister_class(SNA_PT_DEVELOPER_1A58B)
