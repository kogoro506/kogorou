
# 1.5 >>> INTERACTIVE SETTINGS





bl_info = {
    "name": "NOISY-CUTTER",
    "author": "Pictofilmo",
    "version": (0, 1, 6),
    "blender": (4, 0, 0),
    "location": "3D View > FRACTURE",
    "description": "NOISY-CUTTER",
    "warning": "",
    "category": "Object",
}


import bpy
import os
import math
import mathutils
import bmesh
from mathutils import Matrix

from bpy.props import (StringProperty,
                       BoolProperty,
                       IntProperty,
                       FloatProperty,
                       FloatVectorProperty,
                       EnumProperty,
                       PointerProperty,
                       )
from bpy.types import (Panel,
                       Menu,
                       Operator,
                       PropertyGroup,
                       )


# ------------------------------------------------------------------------
#    Scene Properties
# ------------------------------------------------------------------------
def get_material_items(self, context):
    # Generate EnumProperty items based on current materials in the scene
    return [(mat.name, mat.name, "") for mat in bpy.data.materials]    
    
class MyProperties(PropertyGroup):
    my_enum:EnumProperty(
        items=get_material_items,
        name="",
        description="Choose a material from the scene.",
    )
        

    my_string: StringProperty(
        name="",
        description="Cut material name",
        default="NOISY_CUTTER-inside_mat",
        maxlen=1024,
        )

    # Noise setiings ###
    my_noiz: FloatProperty(
        name = "Strength",
        description = "Displacement Strength",
        default = 0.5,
        min = -10,
        max = 10
        )
    my_scal: FloatProperty(
        name = "Scale",
        description = "Noise scale",
        default = 4,
        min = 0,
        max = 200
        )
    my_ndep: IntProperty(
        name = "Levels",
        description = "Noise depth level",
        default = 2,
        min = 0,
        max = 4
        )
    ###################    
        
    my_dens: IntProperty(
        name = "Mesh Density",
        description = "Grid density",
        default = 96,
        min = 10,
        max = 2048,
        )
    my_dep: FloatProperty(
        name = "Length",
        description = "CUTTER extrusion lenght",
        default = 3,
        min = 0.1,
        max = 1500
        )
    my_dep2: FloatProperty(
        name = "Location",
        description = "CUTTER location",
        default = 0,
        min = -1500,
        max = 1500
        )
        
    my_boo: BoolProperty(
        name="Advanced Boolean",
        description="Faster but unstable. Can be use for simple low resolution cut",
        default = True
        ) 


    my_del: BoolProperty(
        name="Delete Cutter after operation",
        description="Delete used mesh after the operation",
        default = True
        )        
    my_del2: BoolProperty(
        name="Delete Spline",
        description="Delete spline after Mesh Cutter creation",
        default = True
        )
#    my_tex: BoolProperty(
#        name="Texture:",
#        description="Use texture instead of noise",
#        default = False
#        )
    my_path : StringProperty(
        name="",
        description="Path to texture",
        default="",
        maxlen=1024,
        subtype='FILE_PATH')

    my_mix: FloatProperty(
        name = "Noise/Texture",
        description = "Mix Noise and Texture",
        default = 0,
        min = 0,
        max = 1
        )  
        
                
    my_disp: FloatProperty(
        name = "Strength",
        description = "Displacement Strength",
        default = 1,
        min = -150,
        max = 150
        )    
        
    my_angl: BoolProperty(
        name="Rotate 90°",
        description="Rotate texture 90°",
        default = False
        )
    my_rot: FloatProperty(
        name = "Rotation",
        description = "texture rotation",
        default = 0,
        min = 0,
        max = 360
        )
        
    
    my_scale2: FloatProperty(
        name = "Scale",
        description = "texture scale",
        default = 1,
        min = 0,
        max = 50
        )



# ------------------------------------------------------------------------
#    FONCTIONS
# ------------------------------------------------------------------------

def ShowMessageBox(message = "", title = "Message Box", icon = 'INFO'):

    def draw(self, context):
        self.layout.label(text=message)

    bpy.context.window_manager.popup_menu(draw, title = title, icon = icon)

    
def value_driver(ob,feed):
    #ex: value_driver(bck1.inputs[1],'prop.col2power')
    drc = ob.driver_add("default_value")
    drc.driver.expression = 'var'
    var = drc.driver.variables.new()
    var.name='var'
    var.type='SINGLE_PROP'
    var.targets[0].id_type = 'SCENE'
    var.targets[0].id = bpy.context.scene
    var.targets[0].data_path=feed  
    return


#initialize NC_cutternodes node group
#initialize NC_cutternodes node group
def NC_cutternodes_node_group():
    NC_cutternodes= bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "NC_cutternodes")

    #initialize NC_cutternodes nodes
    #node Realize Instances
    realize_instances = NC_cutternodes.nodes.new("GeometryNodeRealizeInstances")

    #node Mesh to Points
    mesh_to_points = NC_cutternodes.nodes.new("GeometryNodeMeshToPoints")
    mesh_to_points.mode = 'VERTICES'
    #Selection
    mesh_to_points.inputs[1].default_value = True
    #Position
    mesh_to_points.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Radius
    mesh_to_points.inputs[3].default_value = 0.0

    #node Reroute
    reroute = NC_cutternodes.nodes.new("NodeReroute")
    #node Curve to Mesh
    curve_to_mesh = NC_cutternodes.nodes.new("GeometryNodeCurveToMesh")
    #Fill Caps
    curve_to_mesh.inputs[2].default_value = False

    #node Resample Curve
    resample_curve = NC_cutternodes.nodes.new("GeometryNodeResampleCurve")
    resample_curve.mode = 'LENGTH'
    #Selection
    resample_curve.inputs[1].default_value = True
    #Count
    resample_curve.inputs[2].default_value = 4

    #node Capture Attribute
    capture_attribute = NC_cutternodes.nodes.new("GeometryNodeCaptureAttribute")
    capture_attribute.data_type = 'FLOAT'
    capture_attribute.domain = 'POINT'
    #Value
    capture_attribute.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Value_002
    capture_attribute.inputs[3].default_value = (0.0, 0.0, 0.0, 0.0)
    #Value_003
    capture_attribute.inputs[4].default_value = False
    #Value_004
    capture_attribute.inputs[5].default_value = 0

    #node Capture Attribute.001
    capture_attribute_001 = NC_cutternodes.nodes.new("GeometryNodeCaptureAttribute")
    capture_attribute_001.data_type = 'FLOAT'
    capture_attribute_001.domain = 'POINT'
    #Value
    capture_attribute_001.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Value_002
    capture_attribute_001.inputs[3].default_value = (0.0, 0.0, 0.0, 0.0)
    #Value_003
    capture_attribute_001.inputs[4].default_value = False
    #Value_004
    capture_attribute_001.inputs[5].default_value = 0

    #node Spline Parameter
    spline_parameter = NC_cutternodes.nodes.new("GeometryNodeSplineParameter")

    #node Curve to Mesh.001
    curve_to_mesh_001 = NC_cutternodes.nodes.new("GeometryNodeCurveToMesh")
    #Fill Caps
    curve_to_mesh_001.inputs[2].default_value = False

    #node Vector
    vector = NC_cutternodes.nodes.new("FunctionNodeInputVector")
    vector.vector = (0.0, 0.0, 1.0)

    #node Resample Curve.001
    resample_curve_001 = NC_cutternodes.nodes.new("GeometryNodeResampleCurve")
    resample_curve_001.mode = 'COUNT'
    #Selection
    resample_curve_001.inputs[1].default_value = True
    #Length
    resample_curve_001.inputs[3].default_value = 0.10000000149011612

    #node Curve Length
    curve_length = NC_cutternodes.nodes.new("GeometryNodeCurveLength")

    #node Math
    math = NC_cutternodes.nodes.new("ShaderNodeMath")
    math.operation = 'DIVIDE'
    #Value_002
    math.inputs[2].default_value = 0.5

    #node Math.001
    math_001 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_001.operation = 'DIVIDE'
    #Value_001
    math_001.inputs[1].default_value = 100.0
    #Value_002
    math_001.inputs[2].default_value = 0.5

    #node Math.002
    math_002 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_002.operation = 'MULTIPLY'
    #Value_001
    math_002.inputs[1].default_value = 33.0
    #Value_002
    math_002.inputs[2].default_value = 0.5

    #node Merge by Distance
    merge_by_distance = NC_cutternodes.nodes.new("GeometryNodeMergeByDistance")
    merge_by_distance.mode = 'ALL'
    #Selection
    merge_by_distance.inputs[1].default_value = True

    #node Instance on Points
    instance_on_points = NC_cutternodes.nodes.new("GeometryNodeInstanceOnPoints")
    #Selection
    instance_on_points.inputs[1].default_value = True
    #Pick Instance
    instance_on_points.inputs[3].default_value = False
    #Instance Index
    instance_on_points.inputs[4].default_value = 0
    #Rotation
    instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
    #Scale
    instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)

    #node Reroute.001
    reroute_001 = NC_cutternodes.nodes.new("NodeReroute")
    #node Extrude Mesh
    extrude_mesh = NC_cutternodes.nodes.new("GeometryNodeExtrudeMesh")
    extrude_mesh.mode = 'EDGES'
    #Selection
    extrude_mesh.inputs[1].default_value = True
    #Individual
    extrude_mesh.inputs[4].default_value = True

    #node Voronoi Texture
    voronoi_texture = NC_cutternodes.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.voronoi_dimensions = '3D'
    voronoi_texture.feature = 'SMOOTH_F1'
    voronoi_texture.distance = 'CHEBYCHEV'
    voronoi_texture.inputs[3].default_value = 0.7
    voronoi_texture.inputs[4].default_value = 0.3
    voronoi_texture.inputs[5].default_value = 4
    voronoi_texture.inputs[6].default_value = 1
    voronoi_texture.inputs[8].default_value = 1

    #node Reroute.002
    reroute_002 = NC_cutternodes.nodes.new("NodeReroute")
    #node Position
    position = NC_cutternodes.nodes.new("GeometryNodeInputPosition")

    #node Noise Texture
    noise_texture = NC_cutternodes.nodes.new("ShaderNodeTexNoise")
    noise_texture.noise_dimensions = '3D'
    #W
    noise_texture.inputs[1].default_value = 0.0
    #Detail
    noise_texture.inputs[3].default_value = 10.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.491666704416275
    #Distortion
    noise_texture.inputs[6].default_value = 0.0
    noise_texture.inputs[5].default_value = 2

    #node Noise Texture.001
    noise_texture_001 = NC_cutternodes.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.noise_dimensions = '3D'
    #W
    noise_texture_001.inputs[1].default_value = 0.0
    #Detail
    noise_texture_001.inputs[3].default_value = 12.0
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.4416666626930237
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0

    #node Color Ramp
    color_ramp = NC_cutternodes.nodes.new("ShaderNodeValToRGB")
    color_ramp.color_ramp.color_mode = 'RGB'
    color_ramp.color_ramp.hue_interpolation = 'NEAR'
    color_ramp.color_ramp.interpolation = 'LINEAR'

    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
    color_ramp_cre_0.position = 0.3590909242630005
    color_ramp_cre_0.alpha = 1.0
    color_ramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.5477270483970642)
    color_ramp_cre_1.alpha = 1.0
    color_ramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

    color_ramp_cre_2 = color_ramp.color_ramp.elements.new(0.690909206867218)
    color_ramp_cre_2.alpha = 1.0
    color_ramp_cre_2.color = (0.0, 0.0, 0.0, 1.0)


    #node Reroute.003
    reroute_003 = NC_cutternodes.nodes.new("NodeReroute")
    #node Value
    value = NC_cutternodes.nodes.new("ShaderNodeValue")
    value.label = "subdivision"
    value.use_custom_color = True
    value.color = (0.07854314893484116, 0.6079999804496765, 0.0)

    value.outputs[0].default_value = 247.0
    #node Combine XYZ
    combine_xyz = NC_cutternodes.nodes.new("ShaderNodeCombineXYZ")
    #X
    combine_xyz.inputs[0].default_value = 0.0
    #Y
    combine_xyz.inputs[1].default_value = 0.0

    #node Combine XYZ.001
    combine_xyz_001 = NC_cutternodes.nodes.new("ShaderNodeCombineXYZ")
    #X
    combine_xyz_001.inputs[0].default_value = 0.0
    #Y
    combine_xyz_001.inputs[1].default_value = 0.0




    #node Curve Line
    curve_line = NC_cutternodes.nodes.new("GeometryNodeCurvePrimitiveLine")
    curve_line.mode = 'DIRECTION'

    #node Value.001
    value_001 = NC_cutternodes.nodes.new("ShaderNodeValue")
    value_001.label = "extrusion"
    value_001.use_custom_color = True
    value_001.color = (0.07854314893484116, 0.6079999804496765, 0.0)

    value_001.outputs[0].default_value = 7.28800106048584
    #node Value.002
    value_002 = NC_cutternodes.nodes.new("ShaderNodeValue")
    value_002.label = "location"
    value_002.use_custom_color = True
    value_002.color = (0.07854314893484116, 0.6079999804496765, 0.0)

    value_002.outputs[0].default_value = 0.0
    #NC_cutternodes outputs
    #output Geometry
    #NC_cutternodes.outputs.new('NodeSocketGeometry', "Geometry")
    #NC_cutternodes.outputs[0].attribute_domain = 'POINT'
    NC_cutternodes.interface.new_socket(name="Geometry", in_out='OUTPUT',socket_type='NodeSocketGeometry')

    #output MyUV
#    NC_cutternodes.outputs.new('NodeSocketVector', "MyUV")
#    NC_cutternodes.outputs[1].default_value = (0.0, 0.0, 0.0)
#    NC_cutternodes.outputs[1].min_value = -3.4028234663852886e+38
#    NC_cutternodes.outputs[1].max_value = 3.4028234663852886e+38
#    NC_cutternodes.outputs[1].attribute_domain = 'POINT'
    NC_cutternodes.interface.new_socket(name="MyUV", in_out='OUTPUT',socket_type='NodeSocketVector')


    #node Group Output
    group_output = NC_cutternodes.nodes.new("NodeGroupOutput")

    #node Set Material
    set_material = NC_cutternodes.nodes.new("GeometryNodeSetMaterial")
    #Selection
    set_material.inputs[1].default_value = True
    mat_name="NC_Preview"
    if mat_name in bpy.data.materials:
        set_material.inputs[2].default_value = bpy.data.materials[mat_name]

    #node Set Position
    set_position = NC_cutternodes.nodes.new("GeometryNodeSetPosition")
    #Selection
    set_position.inputs[1].default_value = True
    #Position
    set_position.inputs[2].default_value = (0.0, 0.0, 0.0)

    #node Normal
    normal = NC_cutternodes.nodes.new("GeometryNodeInputNormal")

    #node Vector Math
    vector_math = NC_cutternodes.nodes.new("ShaderNodeVectorMath")
    vector_math.operation = 'MULTIPLY'
    #Vector_002
    vector_math.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math.inputs[3].default_value = 0.06999999284744263

    #node Combine XYZ.002
    combine_xyz_002 = NC_cutternodes.nodes.new("ShaderNodeCombineXYZ")
    #Z
    combine_xyz_002.inputs[2].default_value = 0.0


    #node Math.103
    math_103 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_103.operation = 'MULTIPLY'
    #node Math.203
    math_203 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_203.operation = 'DIVIDE'    
    
    
    #node Color Ramp.001
    color_ramp_001 = NC_cutternodes.nodes.new("ShaderNodeValToRGB")
    color_ramp_001.color_ramp.color_mode = 'RGB'
    color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_001.color_ramp.interpolation = 'LINEAR'

    color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
    color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
    color_ramp_001_cre_0.position = 0.3
    color_ramp_001_cre_0.alpha = 1.0
    color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)

    color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(0.442)
    color_ramp_001_cre_1.alpha = 1.0
    color_ramp_001_cre_1.color = (0.5000001192092896, 0.5000001192092896, 0.5000001192092896, 1.0)

    color_ramp_001_cre_2 = color_ramp_001.color_ramp.elements.new(1)
    color_ramp_001_cre_2.alpha = 1.0
    color_ramp_001_cre_2.color = (0.0, 0.0, 0.0, 1.0)


    #node Mix
    mix = NC_cutternodes.nodes.new("ShaderNodeMix")
    mix.data_type = 'RGBA'
    mix.blend_type = 'SUBTRACT'
    mix.clamp_factor = True
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.333
    #Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix.inputs[2].default_value = 0.0
    #B_Float
    mix.inputs[3].default_value = 0.0
    #A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)

    #node Image Texture
    image_texture = NC_cutternodes.nodes.new("GeometryNodeImageTexture")
    image_texture.interpolation = 'Linear'
    image_texture.extension = 'REPEAT'
    #Frame
    image_texture.inputs[2].default_value = 0

    #node Mix.001
    mix_001 = NC_cutternodes.nodes.new("ShaderNodeMix")
    mix_001.data_type = 'VECTOR'
    mix_001.blend_type = 'SUBTRACT'
    mix_001.clamp_factor = True
    mix_001.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_001.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_001.inputs[2].default_value = 0.0
    #B_Float
    mix_001.inputs[3].default_value = 0.0
    #A_Color
    mix_001.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    #B_Color
    mix_001.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)

    #node Math.703
    math_703 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_703.operation = 'PINGPONG'
    #Value_001
    math_703.inputs[1].default_value = -0.2
    
    
    #node Mix.002
    mix_002 = NC_cutternodes.nodes.new("ShaderNodeMix")
    mix_002.data_type = 'RGBA'
    mix_002.blend_type = 'SOFT_LIGHT'
    mix_002.clamp_factor = True
    mix_002.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_002.inputs[0].default_value = 1.0
    #Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_002.inputs[2].default_value = 0.0
    #B_Float
    mix_002.inputs[3].default_value = 0.0
    #A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)

    #node Reroute.004
    reroute_004 = NC_cutternodes.nodes.new("NodeReroute")
    #node Value.004
    value_004 = NC_cutternodes.nodes.new("ShaderNodeValue")
    value_004.label = "noise scale"
    value_004.use_custom_color = True
    value_004.color = (0.07853920012712479, 0.6080166697502136, 0.0)

    value_004.outputs[0].default_value = 8.289999961853027
    #node Math.003
    math_003 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_003.operation = 'MULTIPLY'
    #Value_001
    math_003.inputs[1].default_value = 8.8
    #Value_002
    math_003.inputs[2].default_value = 0.5

    #node Math.004
    math_004 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_004.operation = 'DIVIDE'
    #Value_001
    math_004.inputs[1].default_value = 100.0
    #Value_002
    math_004.inputs[2].default_value = 0.5

    #node Math.005
    math_005 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_005.operation = 'MULTIPLY'
    #Value_001
    math_005.inputs[1].default_value = 7.0
    #Value_002
    math_005.inputs[2].default_value = 0.5

    #node Math.008
    math_008 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_008.operation = 'MULTIPLY_ADD'

    #node Math.308
    math_308 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_308.operation = 'DIVIDE'
    math_308.inputs[1].default_value = -4
    
    
    #node Math.007
    math_007 = NC_cutternodes.nodes.new("ShaderNodeMath")
    math_007.operation = 'MULTIPLY'
    #Value_002
    math_007.inputs[2].default_value = 0.5

    #node Combine XYZ.003
    combine_xyz_003 = NC_cutternodes.nodes.new("ShaderNodeCombineXYZ")

    #node Vector Math.001
    vector_math_001 = NC_cutternodes.nodes.new("ShaderNodeVectorMath")
    vector_math_001.operation = 'MULTIPLY'
    #Vector_002
    vector_math_001.inputs[2].default_value = (0.0, 0.0, 0.0)
    #Scale
    vector_math_001.inputs[3].default_value = 1.0

    #node Vector Rotate
    vector_rotate = NC_cutternodes.nodes.new("ShaderNodeVectorRotate")
    vector_rotate.rotation_type = 'Z_AXIS'
    #Center
    vector_rotate.inputs[1].default_value = (0.0, 0.0, 0.0)
    #Axis
    vector_rotate.inputs[2].default_value = (0.0, 0.0, 1.0)
    #Rotation
    vector_rotate.inputs[4].default_value = (0.0, 0.0, 0.0)

    #node Value.003
    value_003 = NC_cutternodes.nodes.new("ShaderNodeValue")
    value_003.label = "texture scale"
    value_003.use_custom_color = True
    value_003.color = (0.07853920012712479, 0.6080166697502136, 0.0)

    value_003.outputs[0].default_value = 0.6499997973442078
    #node Value.007
    value_007 = NC_cutternodes.nodes.new("ShaderNodeValue")
    value_007.label = "texture rotation"
    value_007.use_custom_color = True
    value_007.color = (0.07853920012712479, 0.6080166697502136, 0.0)

    value_007.outputs[0].default_value = 0.6499997973442078
    #node Value.006
    value_006 = NC_cutternodes.nodes.new("ShaderNodeValue")
    value_006.label = "NoiseStrenght"
    value_006.use_custom_color = True
    value_006.color = (0.07853920012712479, 0.6080166697502136, 0.0)

    value_006.outputs[0].default_value = 0.460000216960907
    #node Value.005
    value_005 = NC_cutternodes.nodes.new("ShaderNodeValue")
    value_005.label = "TextureStrenght"
    value_005.use_custom_color = True
    value_005.color = (0.07853920012712479, 0.6080166697502136, 0.0)

    value_005.outputs[0].default_value = 0.460000216960907
    #node Mix.004
    mix_004 = NC_cutternodes.nodes.new("ShaderNodeMix")
    mix_004.label = "noise/texture"
    mix_004.data_type = 'RGBA'
    mix_004.blend_type = 'MIX'
    mix_004.clamp_factor = True
    mix_004.factor_mode = 'UNIFORM'
    #Factor_Float
    mix_004.inputs[0].default_value = 0.5
    #Factor_Vector
    mix_004.inputs[1].default_value = (0.5, 0.5, 0.5)
    #A_Float
    mix_004.inputs[2].default_value = 0.0
    #B_Float
    mix_004.inputs[3].default_value = 0.0
    #A_Vector
    mix_004.inputs[4].default_value = (0.0, 0.0, 0.0)
    #B_Vector
    mix_004.inputs[5].default_value = (0.0, 0.0, 0.0)

    #NC_cutternodes inputs
    #input Geometry
    NC_cutternodes.interface.new_socket(name="Geometry", in_out='INPUT',socket_type='NodeSocketGeometry')
    #NC_cutternodes.inputs.new('NodeSocketGeometry', "Geometry")
    #NC_cutternodes.inputs[0].attribute_domain = 'POINT'


    #node Group Input
    group_input = NC_cutternodes.nodes.new("NodeGroupInput")

    #node Set Spline Cyclic
    set_spline_cyclic = NC_cutternodes.nodes.new("GeometryNodeSetSplineCyclic")
    set_spline_cyclic.label = "Cyclic"
    #Selection
    set_spline_cyclic.inputs[1].default_value = True
    #Cyclic
    set_spline_cyclic.inputs[2].default_value = False


    #Set locations
    realize_instances.location = (1625.3570556640625, 216.92161560058594)
    mesh_to_points.location = (1060.6077880859375, 444.56622314453125)
    reroute.location = (359.2701416015625, 468.95977783203125)
    curve_to_mesh.location = (850.9676513671875, 622.3041381835938)
    resample_curve.location = (290.0703125, 788.0751342773438)
    capture_attribute.location = (501.36688232421875, 667.4066772460938)
    capture_attribute_001.location = (-1604.9879150390625, -264.67578125)
    spline_parameter.location = (-2035.8804931640625, -93.99808502197266)
    curve_to_mesh_001.location = (318.1503601074219, 276.13287353515625)
    vector.location = (229.59091186523438, 130.16151428222656)
    resample_curve_001.location = (79.14978790283203, 227.66030883789062)
    curve_length.location = (-1137.0821533203125, -166.0515594482422)
    math.location = (-736.8931884765625, -125.22651672363281)
    math_001.location = (1384.1348876953125, -76.2800521850586)
    math_002.location = (1550.0086669921875, -80.08157348632812)
    merge_by_distance.location = (1863.7066650390625, 278.1953430175781)
    instance_on_points.location = (1354.8026123046875, 349.60595703125)
    reroute_001.location = (-509.3903503417969, -148.8707275390625)
    extrude_mesh.location = (511.0948181152344, 156.06089782714844)
    voronoi_texture.location = (1961.6246337890625, -908.1854248046875)
    reroute_002.location = (1413.0692138671875, -600.5497436523438)
    position.location = (1250.7451171875, -867.4742431640625)
    noise_texture.location = (1953.9503173828125, -661.9360961914062)
    noise_texture_001.location = (2822.680908203125, -839.8191528320312)
    color_ramp.location = (2254.835693359375, -824.603515625)
    reroute_003.location = (-933.4266357421875, 100.00029754638672)
    value.location = (-1218.94091796875, 151.7733917236328)
    combine_xyz.location = (-491.2679748535156, 648.4208374023438)
    combine_xyz_001.location = (-342.5296325683594, 394.85552978515625)
    curve_line.location = (89.63214111328125, 604.3800659179688)
    value_001.location = (-1178.0433349609375, 320.6329650878906)
    value_002.location = (-1155.7454833984375, 520.549560546875)
    group_output.location = (4906.041015625, 167.08641052246094)
    set_material.location = (4525.9423828125, 291.6056213378906)
    set_position.location = (4324.53076171875, 302.6778564453125)
    normal.location = (3635.94140625, -90.5732650756836)
    vector_math.location = (4132.62109375, -129.9733123779297)
    combine_xyz_002.location = (926, -441)
    
    math_103.location =(626, -341)
    math_203.location =(326, -641)
    
    color_ramp_001.location = (3042.796630859375, -831.8735961914062)
    mix.location = (2661.456787109375, -563.0438842773438)
    image_texture.location = (2914.076171875, -240.82704162597656)
    mix_001.location = (1594.2442626953125, -640.5809936523438)
    mix_002.location = (3346.9287109375, -608.0136108398438)
    math_703.location=(3346,-808)
    reroute_004.location = (1428.673095703125, -1084.4708251953125)
    value_004.location = (940.2579345703125, -1052.681640625)
    math_003.location = (1540.03369140625, -934.4384765625)
    math_004.location = (1200.6729736328125, -1027.4017333984375)
    math_005.location = (2504.322998046875, -973.2261962890625)
    math_008.location = (3567.0, -560.841552734375)
    math_308.location = (3567.0, -760)
    math_007.location = (3565.105224609375, -209.89756774902344)
    combine_xyz_003.location = (2047.2548828125, -139.2340087890625)
    vector_math_001.location = (2473.743896484375, -358.96661376953125)
    vector_rotate.location = (2694.0, -196.48040771484375)
    value_003.location = (1793.9305419921875, -175.6825408935547)
    value_007.location = (2224.44921875, -39.12811279296875)
    value_006.location = (3220.49951171875, -425.80133056640625)
    value_005.location = (3203.014892578125, -146.42440795898438)
    mix_004.location = (3846.82080078125, -357.850341796875)
    group_input.location = (-2119.802734375, -444.5818786621094)
    set_spline_cyclic.location = (-1855.0638427734375, -377.0459289550781)



    #initialize NC_cutternodes links
    #capture_attribute_001.Geometry -> resample_curve_001.Curve
    NC_cutternodes.links.new(capture_attribute_001.outputs[0], resample_curve_001.inputs[0])
    #resample_curve_001.Curve -> curve_to_mesh_001.Curve
    NC_cutternodes.links.new(resample_curve_001.outputs[0], curve_to_mesh_001.inputs[0])
    #curve_to_mesh_001.Mesh -> extrude_mesh.Mesh
    NC_cutternodes.links.new(curve_to_mesh_001.outputs[0], extrude_mesh.inputs[0])
    #vector.Vector -> extrude_mesh.Offset
    NC_cutternodes.links.new(vector.outputs[0], extrude_mesh.inputs[2])
    #reroute_003.Output -> resample_curve_001.Count
    NC_cutternodes.links.new(reroute_003.outputs[0], resample_curve_001.inputs[2])
    #reroute_003.Output -> math.Value
    NC_cutternodes.links.new(reroute_003.outputs[0], math.inputs[1])
    #reroute_001.Output -> extrude_mesh.Offset Scale
    NC_cutternodes.links.new(reroute_001.outputs[0], extrude_mesh.inputs[3])
    #mesh_to_points.Points -> instance_on_points.Points
    NC_cutternodes.links.new(mesh_to_points.outputs[0], instance_on_points.inputs[0])
    #extrude_mesh.Mesh -> instance_on_points.Instance
    NC_cutternodes.links.new(extrude_mesh.outputs[0], instance_on_points.inputs[2])
    #set_material.Geometry -> group_output.Geometry
    NC_cutternodes.links.new(set_material.outputs[0], group_output.inputs[0])
    
    
    #capture_attribute_001.Geometry -> curve_length.Curve
    NC_cutternodes.links.new(capture_attribute_001.outputs[0], curve_length.inputs[0])
    #curve_length.Length -> math.Value
    NC_cutternodes.links.new(curve_length.outputs[0], math.inputs[0])
    #instance_on_points.Instances -> realize_instances.Geometry
    NC_cutternodes.links.new(instance_on_points.outputs[0], realize_instances.inputs[0])
    #merge_by_distance.Geometry -> set_position.Geometry
    NC_cutternodes.links.new(merge_by_distance.outputs[0], set_position.inputs[0])
    #set_position.Geometry -> set_material.Geometry
    NC_cutternodes.links.new(set_position.outputs[0], set_material.inputs[0])
    
    #NC_cutternodes.links.new(set_position.outputs[0], group_output.inputs[0])
    
    
    #set_spline_cyclic.Geometry -> capture_attribute_001.Geometry
    NC_cutternodes.links.new(set_spline_cyclic.outputs[0], capture_attribute_001.inputs[0])
    #reroute.Output -> capture_attribute.Value
    NC_cutternodes.links.new(reroute.outputs[0], capture_attribute.inputs[2])
    #spline_parameter.Factor -> capture_attribute_001.Value
    NC_cutternodes.links.new(spline_parameter.outputs[0], capture_attribute_001.inputs[2])
    #combine_xyz_002.Vector -> group_output.MyUV
    NC_cutternodes.links.new(combine_xyz_002.outputs[0], group_output.inputs[1])
    
    #capture_attribute.Attribute -> combine_xyz_002.Y
    #NC_cutternodes.links.new(capture_attribute.outputs[2], combine_xyz_002.inputs[1])
    
    NC_cutternodes.links.new(capture_attribute.outputs[2], math_103.inputs[0])
    NC_cutternodes.links.new(math_103.outputs[0], combine_xyz_002.inputs[1])
    NC_cutternodes.links.new(math_203.outputs[0], math_103.inputs[1])
    NC_cutternodes.links.new(value_001.outputs[0], math_203.inputs[0])
    NC_cutternodes.links.new(curve_length.outputs[0], math_203.inputs[1])
    
    #combine_xyz_001.Vector -> curve_line.End
    NC_cutternodes.links.new(combine_xyz_001.outputs[0], curve_line.inputs[1])
    #combine_xyz_001.Vector -> curve_line.Direction
    NC_cutternodes.links.new(combine_xyz_001.outputs[0], curve_line.inputs[2])
    #capture_attribute_001.Attribute -> combine_xyz_002.X
    NC_cutternodes.links.new(capture_attribute_001.outputs[2], combine_xyz_002.inputs[0])
    #curve_line.Curve -> resample_curve.Curve
    NC_cutternodes.links.new(curve_line.outputs[0], resample_curve.inputs[0])
    #resample_curve.Curve -> capture_attribute.Geometry
    NC_cutternodes.links.new(resample_curve.outputs[0], capture_attribute.inputs[0])
    #capture_attribute.Geometry -> curve_to_mesh.Curve
    NC_cutternodes.links.new(capture_attribute.outputs[0], curve_to_mesh.inputs[0])
    #realize_instances.Geometry -> merge_by_distance.Geometry
    NC_cutternodes.links.new(realize_instances.outputs[0], merge_by_distance.inputs[0])
    #spline_parameter.Factor -> reroute.Input
    NC_cutternodes.links.new(spline_parameter.outputs[0], reroute.inputs[0])
    #curve_to_mesh.Mesh -> mesh_to_points.Mesh
    NC_cutternodes.links.new(curve_to_mesh.outputs[0], mesh_to_points.inputs[0])
    #reroute_001.Output -> resample_curve.Length
    NC_cutternodes.links.new(reroute_001.outputs[0], resample_curve.inputs[3])
    #reroute_001.Output -> math_001.Value
    NC_cutternodes.links.new(reroute_001.outputs[0], math_001.inputs[0])
    #value_001.Value -> curve_line.Length
    NC_cutternodes.links.new(value_001.outputs[0], curve_line.inputs[3])
    #math.Value -> reroute_001.Input
    NC_cutternodes.links.new(math.outputs[0], reroute_001.inputs[0])
    #math_001.Value -> math_002.Value
    NC_cutternodes.links.new(math_001.outputs[0], math_002.inputs[0])
    #math_002.Value -> merge_by_distance.Distance
    NC_cutternodes.links.new(math_002.outputs[0], merge_by_distance.inputs[2])
    #vector_rotate.Vector -> image_texture.Vector
    NC_cutternodes.links.new(vector_rotate.outputs[0], image_texture.inputs[1])
    #combine_xyz_002.Vector -> vector_math_001.Vector
    NC_cutternodes.links.new(combine_xyz_002.outputs[0], vector_math_001.inputs[0])
    #noise_texture.Fac -> mix.A
    NC_cutternodes.links.new(noise_texture.outputs[0], mix.inputs[6])
    #voronoi_texture.Color -> color_ramp.Fac
    NC_cutternodes.links.new(voronoi_texture.outputs[1], color_ramp.inputs[0])
    #color_ramp.Color -> mix.B
    NC_cutternodes.links.new(color_ramp.outputs[0], mix.inputs[7])
    #reroute_004.Output -> math_003.Value
    NC_cutternodes.links.new(reroute_004.outputs[0], math_003.inputs[0])
    #math_003.Value -> noise_texture.Scale
    NC_cutternodes.links.new(math_003.outputs[0], noise_texture.inputs[2])
    NC_cutternodes.links.new(math_003.outputs[0], voronoi_texture.inputs[2])

    #combine_xyz_002.Vector -> reroute_002.Input
    NC_cutternodes.links.new(combine_xyz_002.outputs[0], reroute_002.inputs[0])
    #reroute_002.Output -> mix_001.A
    NC_cutternodes.links.new(reroute_002.outputs[0], mix_001.inputs[4])
    #mix_001.Result -> noise_texture.Vector
    NC_cutternodes.links.new(mix_001.outputs[1], noise_texture.inputs[0])
    #position.Position -> mix_001.B
    NC_cutternodes.links.new(position.outputs[0], mix_001.inputs[5])
    #mix_001.Result -> voronoi_texture.Vector
    NC_cutternodes.links.new(mix_001.outputs[1], voronoi_texture.inputs[0])
    #mix_001.Result -> noise_texture_001.Vector
    NC_cutternodes.links.new(mix_001.outputs[1], noise_texture_001.inputs[0])
    #reroute_004.Output -> math_005.Value
    NC_cutternodes.links.new(reroute_004.outputs[0], math_005.inputs[0])
    #math_005.Value -> noise_texture_001.Scale
    NC_cutternodes.links.new(math_005.outputs[0], noise_texture_001.inputs[2])
    #noise_texture_001.Fac -> color_ramp_001.Fac
    NC_cutternodes.links.new(noise_texture_001.outputs[0], color_ramp_001.inputs[0])
    #value.Value -> reroute_003.Input
    NC_cutternodes.links.new(value.outputs[0], reroute_003.inputs[0])
    #reroute_001.Output -> combine_xyz_001.Z
    NC_cutternodes.links.new(reroute_001.outputs[0], combine_xyz_001.inputs[2])
    #combine_xyz.Vector -> curve_line.Start
    NC_cutternodes.links.new(combine_xyz.outputs[0], curve_line.inputs[0])
    #value_002.Value -> combine_xyz.Z
    NC_cutternodes.links.new(value_002.outputs[0], combine_xyz.inputs[2])
    #normal.Normal -> vector_math.Vector
    NC_cutternodes.links.new(normal.outputs[0], vector_math.inputs[0])
    #combine_xyz_003.Vector -> vector_math_001.Vector
    NC_cutternodes.links.new(combine_xyz_003.outputs[0], vector_math_001.inputs[1])
    #value_003.Value -> combine_xyz_003.X
    NC_cutternodes.links.new(value_003.outputs[0], combine_xyz_003.inputs[0])
    #value_003.Value -> combine_xyz_003.Y
    NC_cutternodes.links.new(value_003.outputs[0], combine_xyz_003.inputs[1])
    #value_003.Value -> combine_xyz_003.Z
    NC_cutternodes.links.new(value_003.outputs[0], combine_xyz_003.inputs[2])
    #mix.Result -> mix_002.A
    NC_cutternodes.links.new(mix.outputs[2], mix_002.inputs[6])
    #color_ramp_001.Color -> mix_002.B
    NC_cutternodes.links.new(color_ramp_001.outputs[0], math_703.inputs[0])
    NC_cutternodes.links.new(math_703.outputs[0], mix_002.inputs[7])
    
    
    
    
    #math_007.Value -> mix_004.A
    NC_cutternodes.links.new(math_007.outputs[0], mix_004.inputs[6])
    #math_008.Value -> mix_004.B
    NC_cutternodes.links.new(math_008.outputs[0], mix_004.inputs[7])
    #mix_004.Result -> vector_math.Vector
    NC_cutternodes.links.new(mix_004.outputs[2], vector_math.inputs[1])
    #math_004.Value -> reroute_004.Input
    NC_cutternodes.links.new(math_004.outputs[0], reroute_004.inputs[0])
    #value_004.Value -> math_004.Value
    NC_cutternodes.links.new(value_004.outputs[0], math_004.inputs[0])
    #vector_math.Vector -> set_position.Offset
    NC_cutternodes.links.new(vector_math.outputs[0], set_position.inputs[3])
    #image_texture.Color -> math_007.Value
    NC_cutternodes.links.new(image_texture.outputs[0], math_007.inputs[0])

    
    #mix_002.Result -> math_008.Value
    NC_cutternodes.links.new(mix_002.outputs[2], math_008.inputs[0])

    #value_006.Value -> math_008.Value
    NC_cutternodes.links.new(value_006.outputs[0], math_008.inputs[1]) 
    NC_cutternodes.links.new(value_006.outputs[0], math_308.inputs[0])    
    NC_cutternodes.links.new(math_308.outputs[0], math_008.inputs[2])  
    
    #value_005.Value -> math_007.Value
    NC_cutternodes.links.new(value_005.outputs[0], math_007.inputs[1])
    #vector_math_001.Vector -> vector_rotate.Vector
    NC_cutternodes.links.new(vector_math_001.outputs[0], vector_rotate.inputs[0])
    #value_007.Value -> vector_rotate.Angle
    NC_cutternodes.links.new(value_007.outputs[0], vector_rotate.inputs[3])
    #group_input.Geometry -> set_spline_cyclic.Geometry
    NC_cutternodes.links.new(group_input.outputs[0], set_spline_cyclic.inputs[0])




    
    #drivers
    value_driver(value_001.outputs[0],'my_prop.my_dep') 
    value_driver(value.outputs[0],'my_prop.my_dens') 
    value_driver(value_004.outputs[0],'my_prop.my_scal')     
    value_driver(value_006.outputs[0],'my_prop.my_noiz')  
    value_driver(value_002.outputs[0],'my_prop.my_dep2') 
    
    value_driver(value_003.outputs[0],'my_prop.my_scale2') 
    value_driver(value_007.outputs[0],'my_prop.my_rot')  
    value_driver(value_005.outputs[0],'my_prop.my_disp') 


    
    
    
    
    
    return NC_cutternodes





# ------------------------------------------------------------------------
#    Operators
# ------------------------------------------------------------------------
class DRAW_button(bpy.types.Operator):
    bl_idname = "wm.decal"
    bl_label = "DRAW CUTTER"
    bl_description="Draw the cut spline. Press TAB to finish. Don't forget to draw in Orthographic view (numpad 5)"

    def execute(self, context):
        sel = bpy.context.selected_objects
        if len(sel)<1:
            ShowMessageBox("Please, select an object first")
        else: 
            ob = bpy.context.view_layer.objects.active
            bpy.context.scene.cursor.location = ob.location   
                
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            ctx = bpy.context.copy()
                            ctx['area'] = area
                            ctx['region'] = region
                            bpy.ops.curve.primitive_bezier_curve_add(radius=1, enter_editmode=True, align='VIEW', location=ob.location, )
                            bpy.context.object.show_in_front = True
                            cv = bpy.context.view_layer.objects.active
                            cv.name='CUTTER_profil'
                            bpy.ops.curve.delete(type='VERT')

                            #bpy.ops.view3d.view_persportho(ctx)
                            bpy.context.scene.tool_settings.curve_paint_settings.curve_type = 'BEZIER'
                            bpy.context.scene.tool_settings.curve_paint_settings.fit_method = 'REFIT'
                            bpy.context.scene.tool_settings.curve_paint_settings.error_threshold = 8
                            bpy.context.scene.tool_settings.curve_paint_settings.use_corners_detect = True
                            bpy.context.scene.tool_settings.curve_paint_settings.corner_angle = 1.22173
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_taper_start = 0
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_taper_end = 0
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_min = 0
                            bpy.context.scene.tool_settings.curve_paint_settings.radius_max = 1
                            bpy.context.scene.tool_settings.curve_paint_settings.use_pressure_radius = False
                            bpy.context.scene.tool_settings.curve_paint_settings.depth_mode = 'CURSOR'

                            bpy.ops.wm.tool_set_by_id(name="builtin.draw")  
                            break 
                        


            
                        
            # MESHER  ##################
            
            # preview material
            mat_name="NC_Preview"
            ng = bpy.data.materials
            if mat_name in ng:
                mat = bpy.data.materials.get(mat_name)
            else:                   
                mat = bpy.data.materials.new(name = mat_name)
                mat.use_nodes = True
                NC_Preview = mat.node_tree
                for node in NC_Preview.nodes:
                    NC_Preview.nodes.remove(node)
                material_output = NC_Preview.nodes.new("ShaderNodeOutputMaterial")
                principled_bsdf = NC_Preview.nodes.new("ShaderNodeBsdfPrincipled")
                principled_bsdf.inputs[0].default_value = (0.04644734039902687, 0.04644734039902687, 0.04644734039902687, 1.0)
                material_output.location = (300.0, 300.0)
                principled_bsdf.location = (-83.83859252929688, 303.24078369140625)
                NC_Preview.links.new(principled_bsdf.outputs[0], material_output.inputs[0])     
                

            #mesher
            obj = bpy.context.active_object
            
            if obj.type == 'CURVE':
                #bpy.ops.object.mode_set(mode="OBJECT")
                
                if bpy.context.scene.my_prop.my_del2 == False :
                    bpy.ops.object.duplicate()
                    duplicated_object = bpy.context.active_object
                    obj.select_set(True)
                    bpy.context.view_layer.objects.active = obj
                    
                
                if 'NC_cutternodes' not in bpy.data.node_groups:
                    NC_cutternodes = NC_cutternodes_node_group()
                else:
                    print("Already here")    
                
                # temp dev mod
    #            NC_cutternodes = NC_cutternodes_node_group()
                
                #ng = bpy.data.node_groups['NC_cutternodes']
                modifier=obj.modifiers.new("Cutter", "NODES")
                #bpy.data.node_groups.remove(modifier.node_group)
                modifier.node_group = bpy.data.node_groups['NC_cutternodes']
                #modifier["Output_1_attribute_name"] = "UVMap"
                modifier["Socket_1_attribute_name"] = "UVMap"


                
                obj.name="CUTTER"
                bpy.context.object.show_in_front = False
                bpy.context.object.show_wire = True

          
            
    #        if event.type == 'RIGHTMOUSE':
    #            if event.value == 'RELEASE': 
    #                bpy.ops.object.mode_set(mode="OBJECT")    
                               
        return {'FINISHED'}        
                                     

class MESHER2_button(bpy.types.Operator):
    bl_idname = "wm.mesher2"
    bl_label = "DRAWING (TAB to exit)"
    bl_description="Stop drawing"
    
    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        return {'FINISHED'}        

class BOOL_button(bpy.types.Operator):
    bl_idname = "wm.boolcut"
    bl_label = "CUT Fast"
    bl_description ="Cut selected objects with the CUTTER plane. Just select the objects before to use the CUT button"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        context = bpy.context
        scene = context.scene
        #cutter = bpy.context.active_object
        print("FAST **************************")
        if bpy.data.objects.get("CUTTER") is not None and len(bpy.context.selected_objects)>0:            
            cutter = bpy.data.objects.get('CUTTER')
            sel = bpy.context.selected_objects
            state=0
            for o in sel:
                if o.type == 'MESH' and o.name!="CUTTER":
                    state+=1
                else:
                    state+=0                    
            if state > 0: 
                cutter = bpy.data.objects.get('CUTTER')   
                bpy.ops.object.select_all(action='DESELECT')
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter                
                # mute material node from geometry nodes
                if 'NC_cutternodes' in bpy.data.node_groups:
                    node_name = "Set Material"     
                    node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
                    node.mute = True                                                    
                #convert to mesh and atribute to UVmap
                bpy.ops.object.convert(target='MESH')
                a = bpy.context.object.data.attributes
                a.active = a['UVMap']
                bpy.ops.geometry.attribute_convert(mode='GENERIC', domain='CORNER', data_type='FLOAT2')
                               
                mat_name=bpy.context.scene.my_prop.my_enum                
                cutter_material = bpy.data.materials.get(mat_name)
                cutter.active_material = cutter_material 
                print("geonode converted to mesh")
                
                                 
                list=[]
                for o in sel:
                     if o != cutter and o.type =='MESH':
                         list.append(o)                
                for ob in list:
                    bpy.ops.object.select_all(action='DESELECT')
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.object.convert(target='MESH')                
                    ob.data.use_auto_smooth = True
                    ob .data.auto_smooth_angle = 0.52                                  
                    # CREATE dummy base Material if object don't have any material   
                    mat_name="NC_Temp"
                    ng = bpy.data.materials
                    if mat_name in ng:
                        dummy_mat = bpy.data.materials.get(mat_name)
                    else:
                        dummy_mat = bpy.data.materials.new(name=mat_name)
                        dummy_mat.diffuse_color = (0.75, 0.75, 0.75,1) 
                        dummy_mat.use_nodes = True
                        nodes = dummy_mat.node_tree.nodes
                        dummy_mat.node_tree.nodes.clear() 
                        princ = nodes.new('ShaderNodeBsdfPrincipled')
                        princ.location = (0,0)
                        outepute= nodes.new('ShaderNodeOutputMaterial')
                        outepute.location=(300,0)
                        dummy_mat.node_tree.links.new(princ.outputs[0], outepute.inputs[0])                 
                    ob_mat = ob.active_material
                    if not ob_mat:
                        ob.data.materials.append(dummy_mat)   
                    if not cutter_material.name in ob.material_slots:
                        ob.data.materials.append(cutter_material)    
                    print("materials ok")     
                                                
                    #Boolean 1                                  
                    mod = ob.modifiers.new('Boolean',type='BOOLEAN')
                    mod.object = cutter
                    mod.operation = 'DIFFERENCE'                    
                    mod.solver = 'FAST'
#                    bpy.ops.object.mode_set(mode="EDIT")
#                    bpy.ops.mesh.select_all(action='SELECT')
#                    bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0)                
#                    bpy.ops.object.mode_set(mode="OBJECT")    
                    #add cutter material to objet
                    print("Boolean1 ok")

                    #Boolean 2    
                    bpy.ops.object.duplicate_move()
                    ob2 = bpy.context.view_layer.objects.active
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT")                
                    bpy.context.view_layer.objects.active = ob  
                    ob.modifiers["Boolean"].operation = 'DIFFERENCE'                    
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT")                    
                    print("Boolean2 ok")           
                             
                if bpy.context.scene.my_prop.my_del == True :
                    bpy.data.objects.remove(cutter, do_unlink=True)
                    print("cutter removed")

         
        # unmute material node from geometry nodes for next operations
        if 'NC_cutternodes' in bpy.data.node_groups:
            node_name = "Set Material"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            node.mute = False  
            print("GeoNode restored for next operation")
            
        return{'FINISHED'}    
class BOOL3_button(bpy.types.Operator):
    bl_idname = "wm.boolcut3"
    bl_label = "CUT Fast"
    bl_description ="Cut selected objects with the CUTTER plane. Just select the objects before to use the CUT button"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        context = bpy.context
        scene = context.scene
        #cutter = bpy.context.active_object
        

            
        print("FAST2 **************************")
        if bpy.data.objects.get("CUTTER") is not None and len(bpy.context.selected_objects)>0:            
            cutter = bpy.data.objects.get('CUTTER')
            sel = bpy.context.selected_objects
            state=0
            for o in sel:
                if o.type == 'MESH' and o.name!="CUTTER":
                    state+=1
                else:
                    state+=0                    
            if state > 0: 
                cutter = bpy.data.objects.get('CUTTER')   
                bpy.ops.object.select_all(action='DESELECT')
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter   
                for modifier in cutter.modifiers:
                    if modifier.type == "NODES":  
                        print("cutter is a Geonode")           
                        # mute material node from geometry nodes
                        if 'NC_cutternodes' in bpy.data.node_groups:
                            node_name = "Set Material"     
                            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
                            node.mute = True                                                    
                        #convert to mesh and atribute to UVmap
                        bpy.ops.object.convert(target='MESH')
                        a = bpy.context.object.data.attributes
                        a.active = a['UVMap']
                        bpy.ops.geometry.attribute_convert(mode='GENERIC', domain='CORNER', data_type='FLOAT2')
                                       
                        mat_name=bpy.context.scene.my_prop.my_enum                
                        cutter_material = bpy.data.materials.get(mat_name)
                        cutter.active_material = cutter_material 
                        print("geonode converted to mesh")
                else:
                    print("Cutter is a mesh")
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter
                mod1 = cutter.modifiers.new('Solidify',type='SOLIDIFY')
                mod1.offset = 0
                mod1.thickness = 0.001

                print("solidify ok")          



                                         
                list=[]
                for o in sel:
                     if o != cutter and o.type =='MESH':
                         list.append(o)                
                for ob in list:
                    bpy.ops.object.select_all(action='DESELECT')
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.object.convert(target='MESH')                
                    ob.data.use_auto_smooth = True
                    ob .data.auto_smooth_angle = 0.52                                  
                    # CREATE dummy base Material if object don't have any material   
                    mat_name="NC_Temp"
                    ng = bpy.data.materials
                    if mat_name in ng:
                        dummy_mat = bpy.data.materials.get(mat_name)
                    else:
                        dummy_mat = bpy.data.materials.new(name=mat_name)
                        dummy_mat.diffuse_color = (0.75, 0.75, 0.75,1) 
                        dummy_mat.use_nodes = True
                        nodes = dummy_mat.node_tree.nodes
                        dummy_mat.node_tree.nodes.clear() 
                        princ = nodes.new('ShaderNodeBsdfPrincipled')
                        princ.location = (0,0)
                        outepute= nodes.new('ShaderNodeOutputMaterial')
                        outepute.location=(300,0)
                        dummy_mat.node_tree.links.new(princ.outputs[0], outepute.inputs[0])                 
                    ob_mat = ob.active_material
                    if not ob_mat:
                        ob.data.materials.append(dummy_mat)   
                        
                    mat_name=bpy.context.scene.my_prop.my_enum                
                    cutter_material = bpy.data.materials.get(mat_name)
                    if not cutter_material.name in ob.material_slots:
                        ob.data.materials.append(cutter_material)    
                    print("materials ok")     
                    

                                                
                    #Boolean 1   
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob                           
                    mod = ob.modifiers.new('Boolean',type='BOOLEAN')
                    mod.object = cutter
                    mod.operation = 'DIFFERENCE'                    
                    mod.solver = 'FAST'
                    bpy.ops.object.convert(target='MESH') 
                    bpy.ops.wm.split()
                    print("boolean OK")  
                             
                if bpy.context.scene.my_prop.my_del == True :
                    bpy.data.objects.remove(cutter, do_unlink=True)
                    print("cutter removed")
                else:
                    cutter.modifiers.clear()

         
        # unmute material node from geometry nodes for next operations
        if 'NC_cutternodes' in bpy.data.node_groups:
            node_name = "Set Material"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            node.mute = False  
            print("GeoNode restored for next operation")
            
        return{'FINISHED'}    
    
        
class BOOL2_button(bpy.types.Operator):
    bl_idname = "wm.boolcut2"
    bl_label = "CUT Advanced"
    bl_description ="Cut selected objects with the CUTTER plane. Just select the objects before to use the CUT button"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        context = bpy.context
        scene = context.scene
        #cutter = bpy.context.active_object
        if bpy.data.objects.get("CUTTER") is not None and len(bpy.context.selected_objects)>0:            
            cutter = bpy.data.objects.get('CUTTER')
            sel = bpy.context.selected_objects
            state=0
            for o in sel:
                if o.type == 'MESH' and o.name!="CUTTER":
                    state+=1
                else:
                    state+=0                    
            if state > 0: 
                cutter = bpy.data.objects.get('CUTTER')   
                bpy.ops.object.select_all(action='DESELECT')
                cutter.select_set(True)
                bpy.context.view_layer.objects.active = cutter   
                for modifier in cutter.modifiers:
                    if modifier.type == "NODES":  
                        print("cutter is a Geonode")           
                        # mute material node from geometry nodes
                        if 'NC_cutternodes' in bpy.data.node_groups:
                            node_name = "Set Material"     
                            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
                            node.mute = True                                                    
                        #convert to mesh and atribute to UVmap
                        bpy.ops.object.convert(target='MESH')
                        a = bpy.context.object.data.attributes
                        a.active = a['UVMap']
                        bpy.ops.geometry.attribute_convert(mode='GENERIC', domain='CORNER', data_type='FLOAT2')
                                       
                        mat_name=bpy.context.scene.my_prop.my_enum                
                        cutter_material = bpy.data.materials.get(mat_name)
                        cutter.active_material = cutter_material 
                        print("geonode converted to mesh")
                else:
                    print("Cutter is a mesh")
                    
                list=[]
                for o in sel:
                     if o != cutter and o.type =='MESH':
                         list.append(o)                
                for ob in list:
                    bpy.ops.object.select_all(action='DESELECT')
                    ob.select_set(True)
                    bpy.context.view_layer.objects.active = ob
                    bpy.ops.object.convert(target='MESH') 
                    ob.data.use_auto_smooth = True
                    ob .data.auto_smooth_angle = 0.872665                                        
                    # CREATE dummy base Material if object don't have any material   
                    mat_name="NC_Temp"
                    ng = bpy.data.materials
                    if mat_name in ng:
                        dummy_mat = bpy.data.materials.get(mat_name)
                    else:
                        dummy_mat = bpy.data.materials.new(name=mat_name)
                        dummy_mat.diffuse_color = (0.75, 0.75, 0.75,1) 
                        dummy_mat.use_nodes = True
                        nodes = dummy_mat.node_tree.nodes
                        dummy_mat.node_tree.nodes.clear() 
                        princ = nodes.new('ShaderNodeBsdfPrincipled')
                        princ.location = (0,0)
                        outepute= nodes.new('ShaderNodeOutputMaterial')
                        outepute.location=(300,0)
                        dummy_mat.node_tree.links.new(princ.outputs[0], outepute.inputs[0])                 
                    ob_mat = ob.active_material
                    if not ob_mat:
                        ob.data.materials.append(dummy_mat)                                 
                    mod = ob.modifiers.new('Boolean',type='BOOLEAN')
                    mod.object = cutter
                    mod.operation = 'DIFFERENCE'

                    mod.solver = 'EXACT'
                    mod.use_hole_tolerant = False
                    mod.use_self = True
                    mod.material_mode = 'TRANSFER'
                        
                    bpy.ops.object.duplicate_move()
                    ob2 = bpy.context.view_layer.objects.active
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT")                
                    bpy.context.view_layer.objects.active = ob                  
                    bpy.ops.object.modifier_apply(modifier="Boolean")
                    bpy.context.view_layer.objects.active = cutter
                    bpy.ops.object.mode_set(mode="EDIT")  
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.flip_normals()
                    bpy.ops.object.mode_set(mode="OBJECT")                    
#                    # DEPLIAGE uv sur la section
#                    bpy.context.view_layer.objects.active = ob 
#                    index = -1
#                    mat_name=bpy.context.scene.my_prop.my_enum
#                    for m in ob.material_slots:
#                        index += 1
#                        bpy.context.object.active_material_index=index 
#                        mat=bpy.context.object.active_material
#                        
#                        if mat.name==mat_name:
#                            bpy.ops.object.mode_set(mode="EDIT")
#                            bpy.ops.mesh.select_all(action='DESELECT')
#                            bpy.ops.object.material_slot_select()
#                            bpy.ops.uv.smart_project()
#                            #bpy.ops.uv.unwrap(method='ANGLE_BASED', margin=0.001)
#                            bpy.ops.object.mode_set(mode="OBJECT")                                             
                if bpy.context.scene.my_prop.my_del == True :
                    bpy.data.objects.remove(cutter, do_unlink=True)

        # unmute material node from geometry nodes for next operations
        if 'NC_cutternodes' in bpy.data.node_groups:
            node_name = "Set Material"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            node.mute = False  
        return{'FINISHED'}    
    
        
class SPLIT_button(bpy.types.Operator):
    bl_idname = "wm.split"
    bl_label = "Split"
    bl_description ="Split disconnected mesh"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context): 
        sel= bpy.context.selected_objects 
        for i in sel:
            bpy.ops.object.editmode_toggle()
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.editmode_toggle()               
        return{'FINISHED'} 
    
class ORIG_button(bpy.types.Operator):
    bl_idname = "wm.orig"
    bl_label = "Origin"
    bl_description ="Set origin to geometry"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context): 
        sel= bpy.context.selected_objects 
        for i in sel:
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')        
        return{'FINISHED'} 
    
class WIR_button(bpy.types.Operator):
    bl_idname = "wm.wir"
    bl_label = "Display Wireframe"
    bl_description ="View wireframe"
    def execute(self, context): 
        sel= bpy.context.selected_objects 
        for i in sel:
            if i.show_wire == False:
                i.show_wire = True
            else:
                i.show_wire = False  
    
        return{'FINISHED'}  





class CYC_button(bpy.types.Operator):
    bl_idname = "wm.cyc"
    bl_label = "Cyclic Profil"
    bl_description ="switch to closed curve"
    def execute(self, context):   
        if bpy.data.objects.get("CUTTER") is not None:
            node_name = "Set Spline Cyclic"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)  
            if node.inputs[2].default_value == False:      
                node.inputs[2].default_value = True
            else:
                node.inputs[2].default_value = False
            return{'FINISHED'}  
            
            
            
                
###--Update   
class UPD_button(bpy.types.Operator):
    bl_idname = "wm.upd"
    bl_label = "Load Texture"
    bl_description ="Update image texture"
    def execute(self, context):   

        my_path=bpy.context.scene.my_prop.my_path                
        tex_name=os.path.basename(my_path)
        ob = bpy.context.view_layer.objects.active                               
        image_exists = tex_name in bpy.data.images
        if image_exists:
            new_img = bpy.data.images[tex_name]
        else:
            if my_path=="":
                new_img = None
            else:    
                new_img = bpy.data.images.load(filepath = my_path)
            
        if 'NC_cutternodes' in bpy.data.node_groups:              
            node_name = "Image Texture"     
            node = bpy.data.node_groups['NC_cutternodes'].nodes.get(node_name)
            node.inputs[0].default_value = new_img

        
        return{'FINISHED'} 


class MAT_button(bpy.types.Operator):
    bl_idname = "wm.mat"
    bl_label = "Add NC_Broken-Concrete Material"
    bl_description ="NC_Broken-Concrete Material is a high definition procedural material"
    def execute(self, context):   
        mat_name="NC_Broken-Concrete"
        ng = bpy.data.materials
        grp = bpy.data.node_groups
        if mat_name not in ng:
            mat = bpy.data.materials.new(name = mat_name)
            mat.use_nodes = True
            cutt = mat.node_tree
            for node in cutt.nodes:
                cutt.nodes.remove(node)
            material_output = cutt.nodes.new("ShaderNodeOutputMaterial")
            principled_bsdf = cutt.nodes.new("ShaderNodeBsdfPrincipled")
            if "CementBreak" not in grp:
                cementbreak= bpy.data.node_groups.new(type = 'ShaderNodeTree', name = "CementBreak")
                group_output = cementbreak.nodes.new("NodeGroupOutput")
            
                cementbreak.interface.new_socket(name="Color", in_out='OUTPUT',socket_type='NodeSocketColor')
                #cementbreak.outputs.new('NodeSocketColor', "Color")

                cementbreak.interface.new_socket(name="Roughness", in_out='OUTPUT',socket_type='NodeSocketColor')
                #cementbreak.outputs.new('NodeSocketColor', "Roughness")

                cementbreak.interface.new_socket(name="Normal", in_out='OUTPUT',socket_type='NodeSocketVector')
                #cementbreak.outputs.new('NodeSocketVector', "Normal")



                cementbreak.interface.new_socket(name="Scale", in_out='INPUT',socket_type='NodeSocketFloat')
                #cementbreak.inputs.new('NodeSocketFloat', "Scale")
                cementbreak.interface.items_tree["Scale"].default_value=0.3
                cementbreak.interface.items_tree["Scale"].min_value = 0.0
                cementbreak.interface.items_tree["Scale"].max_value = 50

                cementbreak.interface.new_socket(name="Generated/UV", in_out='INPUT',socket_type='NodeSocketFloat')
                #cementbreak.inputs.new('NodeSocketFloatFactor', "Generated/UV")
                cementbreak.interface.items_tree["Generated/UV"].default_value = 1.0
                cementbreak.interface.items_tree["Generated/UV"].min_value = 0.0
                cementbreak.interface.items_tree["Generated/UV"].max_value = 1.0
            
            
            
            
            
            
                mix = cementbreak.nodes.new("ShaderNodeMix")
                mix.data_type = 'RGBA'
                mix.clamp_factor = True
                mix.factor_mode = 'UNIFORM'
                mix.blend_type = 'MULTIPLY'
                mix.inputs[0].default_value = 0.6416666507720947
                mix.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix.inputs[2].default_value = 0.0
                mix.inputs[3].default_value = 0.0
                mix.inputs[4].default_value = (0.0, 0.0, 0.0)
                mix.inputs[5].default_value = (0.0, 0.0, 0.0)
                noise_texture = cementbreak.nodes.new("ShaderNodeTexNoise")
                noise_texture.noise_dimensions = '3D'
                noise_texture.inputs[1].default_value = 0.0
                noise_texture.inputs[2].default_value = 8.0
                noise_texture.inputs[3].default_value = 15.0
                noise_texture.inputs[4].default_value = 0.46666666865348816
                noise_texture.inputs[6].default_value = -0.3999999761581421
                noise_texture.inputs[5].default_value = 2
                
                noise_texture_002 = cementbreak.nodes.new("ShaderNodeTexNoise")
                noise_texture_002.noise_dimensions = '3D'
                noise_texture_002.inputs[1].default_value = 0.0
                noise_texture_002.inputs[2].default_value = 48.999996185302734
                noise_texture_002.inputs[3].default_value = 15.0
                noise_texture_002.inputs[4].default_value = 0.8166666626930237
                noise_texture_002.inputs[6].default_value = 0.0
                noise_texture_002.inputs[5].default_value = 2
                voronoi_texture = cementbreak.nodes.new("ShaderNodeTexVoronoi")
                voronoi_texture.voronoi_dimensions = '3D'
                voronoi_texture.feature = 'F1'
                voronoi_texture.distance = 'EUCLIDEAN'
                voronoi_texture.inputs[1].default_value = 0.0
                voronoi_texture.inputs[2].default_value = 500.0
                voronoi_texture.inputs[3].default_value = 1.0
                voronoi_texture.inputs[4].default_value = 0.5
                voronoi_texture.inputs[5].default_value = 1.0                
                
                mix_002 = cementbreak.nodes.new("ShaderNodeMix")
                mix_002.data_type = 'RGBA'
                mix_002.clamp_factor = True
                mix_002.factor_mode = 'UNIFORM'
                mix_002.blend_type = 'LIGHTEN'
                mix_002.inputs[0].default_value = 0.20000000298023224
                mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix_002.inputs[2].default_value = 0.0
                mix_002.inputs[3].default_value = 0.0
                mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
                mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
                voronoi_texture_001 = cementbreak.nodes.new("ShaderNodeTexVoronoi")
                voronoi_texture_001.voronoi_dimensions = '3D'
                voronoi_texture_001.feature = 'F1'
                voronoi_texture_001.distance = 'EUCLIDEAN'
                voronoi_texture_001.inputs[1].default_value = 0.0
                voronoi_texture_001.inputs[2].default_value = 150.0
                voronoi_texture_001.inputs[3].default_value = 1.0
                voronoi_texture_001.inputs[4].default_value = 0.5
                voronoi_texture_001.inputs[5].default_value = 1.0
                color_ramp_004 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_004.color_ramp.color_mode = 'RGB'
                color_ramp_004.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_004.color_ramp.interpolation = 'LINEAR'
                color_ramp_004.color_ramp.elements.remove(color_ramp_004.color_ramp.elements[0])
                color_ramp_004_cre_0 = color_ramp_004.color_ramp.elements[0]
                color_ramp_004_cre_0.position = 0.0
                color_ramp_004_cre_0.alpha = 1.0
                color_ramp_004_cre_0.color = (1.0, 1.0, 1.0, 1.0)
                color_ramp_004_cre_1 = color_ramp_004.color_ramp.elements.new(0.2318180948495865)
                color_ramp_004_cre_1.alpha = 1.0
                color_ramp_004_cre_1.color = (0.0, 0.0, 0.0, 1.0)
                voronoi_texture_002 = cementbreak.nodes.new("ShaderNodeTexVoronoi")
                voronoi_texture_002.voronoi_dimensions = '3D'
                voronoi_texture_002.feature = 'F1'
                voronoi_texture_002.distance = 'EUCLIDEAN'
                voronoi_texture_002.inputs[1].default_value = 0.0
                voronoi_texture_002.inputs[2].default_value = 800.0
                voronoi_texture_002.inputs[3].default_value = 1.0
                voronoi_texture_002.inputs[4].default_value = 0.5
                voronoi_texture_002.inputs[5].default_value = 1.0
                mix_003 = cementbreak.nodes.new("ShaderNodeMix")
                mix_003.data_type = 'RGBA'
                mix_003.clamp_factor = True
                mix_003.factor_mode = 'UNIFORM'
                mix_003.blend_type = 'LIGHTEN'
                mix_003.inputs[0].default_value = 0.14166666567325592
                mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix_003.inputs[2].default_value = 0.0
                mix_003.inputs[3].default_value = 0.0
                mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
                mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
                color_ramp_005 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_005.color_ramp.color_mode = 'RGB'
                color_ramp_005.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_005.color_ramp.interpolation = 'LINEAR'
                color_ramp_005.color_ramp.elements.remove(color_ramp_005.color_ramp.elements[0])
                color_ramp_005_cre_0 = color_ramp_005.color_ramp.elements[0]
                color_ramp_005_cre_0.position = 0.35454532504081726
                color_ramp_005_cre_0.alpha = 1.0
                color_ramp_005_cre_0.color = (0.0, 0.0, 0.0, 1.0)
                color_ramp_005_cre_1 = color_ramp_005.color_ramp.elements.new(0.6590911149978638)
                color_ramp_005_cre_1.alpha = 1.0
                color_ramp_005_cre_1.color = (1.0, 1.0, 1.0, 1.0)
                color_ramp_006 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_006.color_ramp.color_mode = 'RGB'
                color_ramp_006.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_006.color_ramp.interpolation = 'LINEAR'
                color_ramp_006.color_ramp.elements.remove(color_ramp_006.color_ramp.elements[0])
                color_ramp_006_cre_0 = color_ramp_006.color_ramp.elements[0]
                color_ramp_006_cre_0.position = 0.2727271020412445
                color_ramp_006_cre_0.alpha = 1.0
                color_ramp_006_cre_0.color = (0.0, 0.0, 0.0, 1.0)
                color_ramp_006_cre_1 = color_ramp_006.color_ramp.elements.new(0.61363685131073)
                color_ramp_006_cre_1.alpha = 1.0
                color_ramp_006_cre_1.color = (1.0, 1.0, 1.0, 1.0)
                musgrave_texture = cementbreak.nodes.new("ShaderNodeTexMusgrave")
                musgrave_texture.musgrave_dimensions = '3D'
                musgrave_texture.musgrave_type = 'FBM'
                musgrave_texture.inputs[1].default_value = 0.0
                musgrave_texture.inputs[2].default_value = 1.1000001430511475
                musgrave_texture.inputs[3].default_value = 15.0
                musgrave_texture.inputs[4].default_value = 0.0
                musgrave_texture.inputs[5].default_value = 2.0
                musgrave_texture.inputs[6].default_value = 0.0
                musgrave_texture.inputs[7].default_value = 1.0
                mix_004 = cementbreak.nodes.new("ShaderNodeMix")
                mix_004.data_type = 'RGBA'
                mix_004.clamp_factor = True
                mix_004.factor_mode = 'UNIFORM'
                mix_004.blend_type = 'MULTIPLY'
                mix_004.inputs[0].default_value = 0.17874985933303833
                mix_004.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix_004.inputs[2].default_value = 0.0
                mix_004.inputs[3].default_value = 0.0
                mix_004.inputs[4].default_value = (0.0, 0.0, 0.0)
                mix_004.inputs[5].default_value = (0.0, 0.0, 0.0)
                mix_005 = cementbreak.nodes.new("ShaderNodeMix")
                mix_005.data_type = 'RGBA'
                mix_005.clamp_factor = True
                mix_005.factor_mode = 'UNIFORM'
                mix_005.blend_type = 'MULTIPLY'
                mix_005.inputs[0].default_value = 0.3333333730697632
                mix_005.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix_005.inputs[2].default_value = 0.0
                mix_005.inputs[3].default_value = 0.0
                mix_005.inputs[4].default_value = (0.0, 0.0, 0.0)
                mix_005.inputs[5].default_value = (0.0, 0.0, 0.0)
                math = cementbreak.nodes.new("ShaderNodeMath")
                math.operation = 'MINIMUM'
                math.inputs[1].default_value = 0.11000001430511475
                math.inputs[2].default_value = 0.5
                noise_texture_001 = cementbreak.nodes.new("ShaderNodeTexNoise")
                noise_texture_001.noise_dimensions = '3D'
                noise_texture_001.inputs[1].default_value = 0.0
                noise_texture_001.inputs[2].default_value = 53.10000228881836
                noise_texture_001.inputs[3].default_value = 15.0
                noise_texture_001.inputs[4].default_value = 0.699999988079071
                noise_texture_001.inputs[6].default_value = 0.29999998211860657
                noise_texture_001.inputs[5].default_value = 2
                mapping = cementbreak.nodes.new("ShaderNodeMapping")
                mapping.vector_type = 'POINT'
                mapping.inputs[1].default_value = (0.0, 0.0, 0.0)
                mapping.inputs[2].default_value = (0.0, 0.0, 0.0)
                bump = cementbreak.nodes.new("ShaderNodeBump")
                bump.inputs[0].default_value = 0.4166666865348816
                bump.inputs[1].default_value = 1.0
                bump.inputs[3].default_value = (0.0, 0.0, 0.0)
                math_001 = cementbreak.nodes.new("ShaderNodeMath")
                math_001.operation = 'MINIMUM'
                math_001.inputs[1].default_value = 0.5
                math_001.inputs[2].default_value = 0.5
                bump_001 = cementbreak.nodes.new("ShaderNodeBump")
                bump_001.inputs[0].default_value = 1.0
                bump_001.inputs[1].default_value = 1.0
                reroute = cementbreak.nodes.new("NodeReroute")
                value = cementbreak.nodes.new("ShaderNodeValue")
                value.outputs[0].default_value = 0.20000000298023224
                combine_xyz = cementbreak.nodes.new("ShaderNodeCombineXYZ")
                color_ramp_008 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_008.color_ramp.color_mode = 'RGB'
                color_ramp_008.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_008.color_ramp.interpolation = 'LINEAR'
                color_ramp_008.color_ramp.elements.remove(color_ramp_008.color_ramp.elements[0])
                color_ramp_008_cre_0 = color_ramp_008.color_ramp.elements[0]
                color_ramp_008_cre_0.position = 0.08636365085840225
                color_ramp_008_cre_0.alpha = 1.0
                color_ramp_008_cre_0.color = (1.0, 1.0, 1.0, 1.0)
                color_ramp_008_cre_1 = color_ramp_008.color_ramp.elements.new(0.10454563796520233)
                color_ramp_008_cre_1.alpha = 1.0
                color_ramp_008_cre_1.color = (0.6665030121803284, 0.6665030121803284, 0.6665030121803284, 1.0)
                color_ramp_009 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_009.color_ramp.color_mode = 'RGB'
                color_ramp_009.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_009.color_ramp.interpolation = 'LINEAR'
                color_ramp_009.color_ramp.elements.remove(color_ramp_009.color_ramp.elements[0])
                color_ramp_009_cre_0 = color_ramp_009.color_ramp.elements[0]
                color_ramp_009_cre_0.position = 0.0022728033363819122
                color_ramp_009_cre_0.alpha = 1.0
                color_ramp_009_cre_0.color = (0.2559399902820587, 0.2149450033903122, 0.1782190054655075, 1.0)
                color_ramp_009_cre_1 = color_ramp_009.color_ramp.elements.new(0.10000000149011612)
                color_ramp_009_cre_1.alpha = 1.0
                color_ramp_009_cre_1.color = (0.007591492962092161, 0.007049869745969772, 0.006925624795258045, 1.0)
                color_ramp_009_cre_2 = color_ramp_009.color_ramp.elements.new(0.7454545497894287)
                color_ramp_009_cre_2.alpha = 1.0
                color_ramp_009_cre_2.color = (0.8207942843437195, 0.6549906134605408, 0.5368729829788208, 1.0)
                color_ramp_009_cre_3 = color_ramp_009.color_ramp.elements.new(0.8443177938461304)
                color_ramp_009_cre_3.alpha = 1.0
                color_ramp_009_cre_3.color = (0.255940318107605, 0.21494503319263458, 0.17821893095970154, 1.0)
                color_ramp_009_cre_4 = color_ramp_009.color_ramp.elements.new(1.0)
                color_ramp_009_cre_4.alpha = 1.0
                color_ramp_009_cre_4.color = (0.40715470910072327, 0.4871503412723541, 0.5049578547477722, 1.0)
                reroute_001 = cementbreak.nodes.new("NodeReroute")
                mix_006 = cementbreak.nodes.new("ShaderNodeMix")
                mix_006.data_type = 'VECTOR'
                mix_006.clamp_factor = True
                mix_006.factor_mode = 'UNIFORM'
                mix_006.blend_type = 'MIX'
                mix_006.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix_006.inputs[2].default_value = 0.0
                mix_006.inputs[3].default_value = 0.0
                mix_006.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
                texture_coordinate = cementbreak.nodes.new("ShaderNodeTexCoord")
                group_input = cementbreak.nodes.new("NodeGroupInput")
                


            
                color_ramp_007 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_007.color_ramp.color_mode = 'RGB'
                color_ramp_007.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_007.color_ramp.interpolation = 'LINEAR'
                color_ramp_007.color_ramp.elements.remove(color_ramp_007.color_ramp.elements[0])
                color_ramp_007_cre_0 = color_ramp_007.color_ramp.elements[0]
                color_ramp_007_cre_0.position = 0.2590910792350769
                color_ramp_007_cre_0.alpha = 1.0
                color_ramp_007_cre_0.color = (0.0, 0.0, 0.0, 1.0)
                color_ramp_007_cre_1 = color_ramp_007.color_ramp.elements.new(0.7590910196304321)
                color_ramp_007_cre_1.alpha = 1.0
                color_ramp_007_cre_1.color = (1.0, 1.0, 1.0, 1.0)
                noise_texture_003 = cementbreak.nodes.new("ShaderNodeTexNoise")
                noise_texture_003.noise_dimensions = '3D'
                noise_texture_003.inputs[1].default_value = 0.0
                noise_texture_003.inputs[2].default_value = 5.0
                noise_texture_003.inputs[3].default_value = 15.0
                noise_texture_003.inputs[4].default_value = 0.574999988079071
                noise_texture_003.inputs[6].default_value = 0.0
                noise_texture_003.inputs[5].default_value = 2
                color_ramp = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp.color_ramp.color_mode = 'RGB'
                color_ramp.color_ramp.hue_interpolation = 'NEAR'
                color_ramp.color_ramp.interpolation = 'LINEAR'
                color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
                color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
                color_ramp_cre_0.position = 0.33636367321014404
                color_ramp_cre_0.alpha = 1.0
                color_ramp_cre_0.color = (0.23693320155143738, 0.23693320155143738, 0.23693320155143738, 1.0)
                color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.5863640308380127)
                color_ramp_cre_1.alpha = 1.0
                color_ramp_cre_1.color = (0.33585554361343384, 0.33585554361343384, 0.33585554361343384, 1.0)
                color_ramp_001 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_001.color_ramp.color_mode = 'RGB'
                color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_001.color_ramp.interpolation = 'LINEAR'
                color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
                color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
                color_ramp_001_cre_0.position = 0.31363630294799805
                color_ramp_001_cre_0.alpha = 1.0
                color_ramp_001_cre_0.color = (0.0, 0.0, 0.0, 1.0)
                color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(1.0)
                color_ramp_001_cre_1.alpha = 1.0
                color_ramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)
                color_ramp_003 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_003.color_ramp.color_mode = 'RGB'
                color_ramp_003.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_003.color_ramp.interpolation = 'LINEAR'
                color_ramp_003.color_ramp.elements.remove(color_ramp_003.color_ramp.elements[0])
                color_ramp_003_cre_0 = color_ramp_003.color_ramp.elements[0]
                color_ramp_003_cre_0.position = 0.0
                color_ramp_003_cre_0.alpha = 1.0
                color_ramp_003_cre_0.color = (1.0, 1.0, 1.0, 1.0)
                color_ramp_003_cre_1 = color_ramp_003.color_ramp.elements.new(0.2954545021057129)
                color_ramp_003_cre_1.alpha = 1.0
                color_ramp_003_cre_1.color = (0.0, 0.0, 0.0, 1.0)
                color_ramp_002 = cementbreak.nodes.new("ShaderNodeValToRGB")
                color_ramp_002.color_ramp.color_mode = 'RGB'
                color_ramp_002.color_ramp.hue_interpolation = 'NEAR'
                color_ramp_002.color_ramp.interpolation = 'B_SPLINE'
                color_ramp_002.color_ramp.elements.remove(color_ramp_002.color_ramp.elements[0])
                color_ramp_002_cre_0 = color_ramp_002.color_ramp.elements[0]
                color_ramp_002_cre_0.position = 0.5272727608680725
                color_ramp_002_cre_0.alpha = 1.0
                color_ramp_002_cre_0.color = (0.0, 0.0, 0.0, 1.0)
                color_ramp_002_cre_1 = color_ramp_002.color_ramp.elements.new(1.0)
                color_ramp_002_cre_1.alpha = 1.0
                color_ramp_002_cre_1.color = (1.0, 1.0, 1.0, 1.0)
                mix_001 = cementbreak.nodes.new("ShaderNodeMix")
                mix_001.data_type = 'RGBA'
                mix_001.clamp_factor = True
                mix_001.factor_mode = 'UNIFORM'
                mix_001.blend_type = 'LIGHTEN'
                mix_001.inputs[0].default_value = 0.6083333492279053
                mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix_001.inputs[2].default_value = 0.0
                mix_001.inputs[3].default_value = 0.0
                mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
                mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
                rgb_curves = cementbreak.nodes.new("ShaderNodeRGBCurve")
                rgb_curves.mapping.extend = 'EXTRAPOLATED'
                rgb_curves.mapping.tone = 'STANDARD'
                rgb_curves.mapping.black_level = (0.0, 0.0, 0.0)
                rgb_curves.mapping.white_level = (1.0, 1.0, 1.0)
                rgb_curves.mapping.clip_min_x = 0.0
                rgb_curves.mapping.clip_min_y = 0.0
                rgb_curves.mapping.clip_max_x = 1.0
                rgb_curves.mapping.clip_max_y = 1.0
                rgb_curves.mapping.use_clip = True
                rgb_curves_curve_0 = rgb_curves.mapping.curves[0]
                rgb_curves_curve_0_point_0 = rgb_curves_curve_0.points[0]
                rgb_curves_curve_0_point_0.location = (0.0, 0.0)
                rgb_curves_curve_0_point_0.handle_type = 'AUTO'
                rgb_curves_curve_0_point_1 = rgb_curves_curve_0.points[1]
                rgb_curves_curve_0_point_1.location = (1.0, 1.0)
                rgb_curves_curve_0_point_1.handle_type = 'AUTO'
                rgb_curves_curve_1 = rgb_curves.mapping.curves[1]
                rgb_curves_curve_1_point_0 = rgb_curves_curve_1.points[0]
                rgb_curves_curve_1_point_0.location = (0.0, 0.0)
                rgb_curves_curve_1_point_0.handle_type = 'AUTO'
                rgb_curves_curve_1_point_1 = rgb_curves_curve_1.points[1]
                rgb_curves_curve_1_point_1.location = (1.0, 1.0)
                rgb_curves_curve_1_point_1.handle_type = 'AUTO'
                rgb_curves_curve_2 = rgb_curves.mapping.curves[2]
                rgb_curves_curve_2_point_0 = rgb_curves_curve_2.points[0]
                rgb_curves_curve_2_point_0.location = (0.0, 0.0)
                rgb_curves_curve_2_point_0.handle_type = 'AUTO'
                rgb_curves_curve_2_point_1 = rgb_curves_curve_2.points[1]
                rgb_curves_curve_2_point_1.location = (1.0, 1.0)
                rgb_curves_curve_2_point_1.handle_type = 'AUTO'
                rgb_curves_curve_3 = rgb_curves.mapping.curves[3]
                rgb_curves_curve_3_point_0 = rgb_curves_curve_3.points[0]
                rgb_curves_curve_3_point_0.location = (0.0, 0.0)
                rgb_curves_curve_3_point_0.handle_type = 'AUTO'
                rgb_curves_curve_3_point_1 = rgb_curves_curve_3.points[1]
                rgb_curves_curve_3_point_1.location = (0.3863637149333954, 0.5812502503395081)
                rgb_curves_curve_3_point_1.handle_type = 'AUTO'
                rgb_curves_curve_3_point_2 = rgb_curves_curve_3.points.new(1.0, 1.0)
                rgb_curves_curve_3_point_2.handle_type = 'AUTO'
                rgb_curves.mapping.update()
                rgb_curves.inputs[0].default_value = 1.0
                mix_007 = cementbreak.nodes.new("ShaderNodeMix")
                mix_007.data_type = 'RGBA'
                mix_007.factor_mode = 'UNIFORM'
                mix_007.blend_type = 'MIX'
                mix_007.inputs[0].default_value = 0.06666665524244308
                mix_007.inputs[1].default_value = (0.5, 0.5, 0.5)
                mix_007.inputs[2].default_value = 0.0
                mix_007.inputs[3].default_value = 0.0
                mix_007.inputs[4].default_value = (0.0, 0.0, 0.0)
                mix_007.inputs[5].default_value = (0.0, 0.0, 0.0)
                group_output.location = (2382.877685546875, 0.0)
                mix.location = (-871.081298828125, -543.5820922851562)
                noise_texture.location = (-1430.35107421875, -523.9736328125)
                noise_texture_002.location = (-1353.259521484375, -230.15625)
                voronoi_texture.location = (-1062.544677734375, 72.4432373046875)
                mix_002.location = (-448.073486328125, -59.042724609375)
                voronoi_texture_001.location = (-1085.463623046875, 380.614501953125)
                color_ramp_004.location = (-877.2388305664062, 370.860107421875)
                voronoi_texture_002.location = (-795.6710205078125, 734.092529296875)
                mix_003.location = (-283.3436584472656, 239.0950927734375)
                color_ramp_005.location = (-587.4462890625, 724.338134765625)
                color_ramp_006.location = (30.85089111328125, 963.201416015625)
                musgrave_texture.location = (-234.84046936035156, 937.4302978515625)
                mix_004.location = (61.446014404296875, 383.026123046875)
                mix_005.location = (523.9804077148438, 737.61474609375)
                math.location = (1081.031005859375, -266.1675109863281)
                noise_texture_001.location = (-1428.083740234375, -773.548095703125)
                mapping.location = (-1719.2822265625, 220.03448486328125)
                bump.location = (1446.1806640625, -471.2725830078125)
                math_001.location = (1300.224365234375, -963.2013549804688)
                bump_001.location = (1706.75341796875, -733.7386474609375)
                reroute.location = (1596.945556640625, -247.8326416015625)
                value.location = (-2092.877685546875, -353.2252197265625)
                combine_xyz.location = (-1838.212158203125, -200.6505126953125)
                color_ramp_008.location = (1764.22216796875, -401.51025390625)
                color_ramp_009.location = (1657.839599609375, -86.81884765625)
                reroute_001.location = (-1881.3782958984375, -315.0534362792969)
                mix_006.location = (-1997.3316650390625, 306.4582824707031)
                texture_coordinate.location = (-2263.2373046875, 315.9768371582031)
                group_input.location = (-2292.877685546875, 0.0)
                color_ramp_007.location = (408.39312744140625, -1097.2930908203125)
                noise_texture_003.location = (208.0633087158203, -1099.379638671875)
                color_ramp.location = (-1230.464111328125, -519.759033203125)
                color_ramp_001.location = (-1228.1966552734375, -769.33349609375)
                color_ramp_003.location = (-854.3198852539062, 62.6888427734375)
                color_ramp_002.location = (-1153.372314453125, -225.941650390625)
                mix_001.location = (-690.822998046875, -301.9483642578125)
                rgb_curves.location = (2092.877685546875, -67.9710693359375)
                mix_007.location = (743.0107421875, -964.6243286132812)
                cementbreak.links.new(mapping.outputs[0], noise_texture_003.inputs[0])
                cementbreak.links.new(bump.outputs[0], bump_001.inputs[3])
                cementbreak.links.new(color_ramp.outputs[0], mix.inputs[6])
                cementbreak.links.new(reroute_001.outputs[0], combine_xyz.inputs[2])
                cementbreak.links.new(reroute_001.outputs[0], combine_xyz.inputs[0])
                cementbreak.links.new(combine_xyz.outputs[0], mapping.inputs[3])
                cementbreak.links.new(voronoi_texture.outputs[0], color_ramp_003.inputs[0])
                cementbreak.links.new(mix_007.outputs[2], math_001.inputs[0])
                cementbreak.links.new(color_ramp_005.outputs[0], mix_004.inputs[7])
                cementbreak.links.new(color_ramp_002.outputs[0], mix_001.inputs[7])
                cementbreak.links.new(voronoi_texture_002.outputs[0], color_ramp_005.inputs[0])
                cementbreak.links.new(noise_texture_003.outputs[0], color_ramp_007.inputs[0])
                cementbreak.links.new(mix_004.outputs[2], mix_005.inputs[6])
                cementbreak.links.new(reroute.outputs[0], color_ramp_009.inputs[0])
                cementbreak.links.new(color_ramp_006.outputs[0], mix_005.inputs[7])
                cementbreak.links.new(color_ramp_009.outputs[0], rgb_curves.inputs[1])
                cementbreak.links.new(musgrave_texture.outputs[0], color_ramp_006.inputs[0])
                cementbreak.links.new(color_ramp_003.outputs[0], mix_002.inputs[7])
                cementbreak.links.new(mapping.outputs[0], musgrave_texture.inputs[0])
                cementbreak.links.new(noise_texture.outputs[0], color_ramp.inputs[0])
                cementbreak.links.new(reroute_001.outputs[0], combine_xyz.inputs[1])
                cementbreak.links.new(mapping.outputs[0], noise_texture_001.inputs[0])
                cementbreak.links.new(noise_texture_001.outputs[0], color_ramp_001.inputs[0])
                cementbreak.links.new(mapping.outputs[0], voronoi_texture_001.inputs[0])
                cementbreak.links.new(mix.outputs[2], mix_001.inputs[6])
                cementbreak.links.new(mapping.outputs[0], noise_texture_002.inputs[0])
                cementbreak.links.new(mapping.outputs[0], noise_texture.inputs[0])
                cementbreak.links.new(mix_002.outputs[2], mix_003.inputs[6])
                cementbreak.links.new(math.outputs[0], bump.inputs[2])
                cementbreak.links.new(math_001.outputs[0], bump_001.inputs[2])
                cementbreak.links.new(mix_001.outputs[2], mix_002.inputs[6])
                cementbreak.links.new(mix_005.outputs[2], reroute.inputs[0])
                cementbreak.links.new(mapping.outputs[0], voronoi_texture_002.inputs[0])
                cementbreak.links.new(reroute.outputs[0], color_ramp_008.inputs[0])
                cementbreak.links.new(mix_005.outputs[2], math.inputs[0])
                cementbreak.links.new(color_ramp_004.outputs[0], mix_003.inputs[7])
                cementbreak.links.new(color_ramp_001.outputs[0], mix.inputs[7])
                cementbreak.links.new(mapping.outputs[0], voronoi_texture.inputs[0])
                cementbreak.links.new(voronoi_texture_001.outputs[0], color_ramp_004.inputs[0])
                cementbreak.links.new(mix_003.outputs[2], mix_004.inputs[6])
                cementbreak.links.new(noise_texture_002.outputs[0], color_ramp_002.inputs[0])
                cementbreak.links.new(bump_001.outputs[0], group_output.inputs[2])
                cementbreak.links.new(color_ramp_008.outputs[0], group_output.inputs[1])
                cementbreak.links.new(rgb_curves.outputs[0], group_output.inputs[0])
                cementbreak.links.new(group_input.outputs[0], reroute_001.inputs[0])
                cementbreak.links.new(texture_coordinate.outputs[0], mix_006.inputs[6])
                cementbreak.links.new(texture_coordinate.outputs[0], mix_006.inputs[4])
                cementbreak.links.new(texture_coordinate.outputs[2], mix_006.inputs[5])
                cementbreak.links.new(group_input.outputs[1], mix_006.inputs[0])
                cementbreak.links.new(mix_006.outputs[1], mapping.inputs[0])
                cementbreak.links.new(color_ramp_007.outputs[0], mix_007.inputs[6])
                cementbreak.links.new(color_ramp_002.outputs[0], mix_007.inputs[7])
            group = cutt.nodes.new("ShaderNodeGroup")
            group.node_tree = bpy.data.node_groups["CementBreak"]
            group.inputs[0].default_value = 1.4199999570846558
            group.inputs[1].default_value = 1.0
            material_output.location = (3554.216796875, 898.7608642578125)
            principled_bsdf.location = (3154.58935546875, 602.2632446289062)
            group.location = (2639.771484375, 369.4585266113281)
            material_output.width, material_output.height = 140.0, 100.0
            principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
            group.width, group.height = 251.53857421875, 100.0
            cutt.links.new(group.outputs[2], principled_bsdf.inputs[5])
            cutt.links.new(group.outputs[1], principled_bsdf.inputs[2])
            cutt.links.new(group.outputs[0], principled_bsdf.inputs[0])
            cutt.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
            

            bpy.context.scene.my_prop.my_enum = 'NC_Broken-Concrete'

            return{'FINISHED'}  

            
class RESET_button(bpy.types.Operator):
    bl_idname = "wm.reset"
    bl_label = "Reset material"
    bl_description ="Reset Noisy Cutter custom materials"
    def execute(self, context):
        
        mat_name="NC_Broken-Concrete"
        ng = bpy.data.materials
        if mat_name in ng:
            material = bpy.data.materials.get(mat_name)
            material.name="NC_Broken-Concrete-RESETED"   
            print("NC_Broken-Concrete reseted")   
            
        mat_name="NC_Preview"
        ng = bpy.data.materials
        if mat_name in ng:
            material = bpy.data.materials.get(mat_name)
            material.name="NC_Preview-RESETED"   
            print("NC_Preview reseted")  

        mat_name="NC_Temp"
        ng = bpy.data.materials
        if mat_name in ng:
            material = bpy.data.materials.get(mat_name)
            material.name="NC_Temp-RESETED"   
            print("NC_Temp reseted") 
                        
                                
        return{'FINISHED'}                        
                                    
class RESET2_button(bpy.types.Operator):
    bl_idname = "wm.reset2"
    bl_label = "Reset tools"
    bl_description ="Reset Noisy Cutter operation. Use it only if something gone wrong"
    def execute(self, context):
                                
        if 'NC_cutternodes' in bpy.data.node_groups:
            group = bpy.data.node_groups['NC_cutternodes']
            group.name='NC_cutternodes-RESETED'   
            print("Geometry Node cutternode reseted")   
        
        if 'CUTTER' in bpy.data.objects:
            cutter = bpy.data.objects.get('CUTTER')
            cutter.name= 'CUTTER-RESETED'
            bpy.data.objects.remove(cutter, do_unlink=True)
            print("CUTTER object deleted")   
                      
        if 'CUTTER_profil' in bpy.data.objects:
            cutter_p = bpy.data.objects.get('CUTTER_profil')
            cutter_p.name= 'CUTTER_profil-RESETED'
            bpy.data.objects.remove(cutter_p, do_unlink=True)
            print("CUTTER_profil curve deleted")   
                                
        return{'FINISHED'}                        
                        
# ------------------------------------------------------------------------
#    Menus
# ------------------------------------------------------------------------


# ------------------------------------------------------------------------
#    Panel in Object Mode
# ------------------------------------------------------------------------
class NoizyCuttPanel:

    bl_space_type = "VIEW_3D"   
    bl_region_type = "UI"
    bl_category = "FRACTURE"
    #bl_context = "objectmode"  
    
class NCMAIN_PT_PANEL(NoizyCuttPanel, bpy.types.Panel):
    bl_idname = "NCMAIN_PT_PANEL"
    bl_label = "NOISY-CUTTER 1.6"
    
                




#    @classmethod
#    def poll(self,context):
#        return context.object is not None

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        my_prop = scene.my_prop
        
        ##### INSTRUCTIONS ###############################
        obj = bpy.context.active_object


        row = layout.row(align=True) 
        curv = [obj for obj in bpy.context.scene.objects if obj.name.startswith("CUTTER_profil")]
        cutt = [obj for obj in bpy.context.scene.objects if obj.name.startswith("CUTTER")]
            
        col = layout.column(align=True)        
        row = layout.row(align=True)    


        
        if bpy.data.objects.get("CUTTER_profil")is None and bpy.data.objects.get("CUTTER") is None:
            row = layout.row(align=True)          
            row.operator("wm.decal",icon='GREASEPENCIL')
            row.scale_y=3
        
        if bpy.data.objects.get("CUTTER_profil") is not None:
            row = layout.row(align=True)  
            row.operator("wm.mesher2",icon='MESH_GRID')
            row.scale_y=3
        if bpy.data.objects.get("CUTTER") is not None and context.active_object.mode == 'EDIT':
            row = layout.row(align=True)  
            row.operator("wm.mesher2",depress=True,icon='MESH_GRID')
            row.scale_y=3
        if bpy.data.objects.get("CUTTER") is not None and context.active_object.mode != 'EDIT':
            row = layout.row(align=True)  
            #row.operator("wm.boolcut",icon='MOD_BOOLEAN')
            
            row.operator("wm.boolcut3",icon='MOD_BOOLEAN')
            row.operator("wm.boolcut2",icon='MOD_BOOLEAN')
            row.scale_y=3
            row = layout.row(align=True)   
            row.operator("wm.reset2",text='Cancel Operation')


            
        if bpy.data.objects.get("CUTTER") is not None:
            if bpy.data.node_groups["NC_cutternodes"].nodes["Set Spline Cyclic"].inputs[2].default_value == False:  
                row = layout.row(align=True)                        
                row.operator("wm.cyc",depress=False,text="Cyclic : off")
                row.scale_y=1
            else:
                row = layout.row(align=True)  
                row.operator("wm.cyc",depress=True,text="Cyclic : on")                
                row.scale_y=1
        



        row = layout.row(align=True)  
        row.prop(my_prop, "my_del")
        #row.prop(my_prop, "my_del2")
        #row.prop(my_prop, "my_boo")


        box = layout.box()
        split = box.split()
        col = split.column(align=True)        
        row = col.row(align=True)
            
          
        row.label(text="Cutter:",icon='GRID')
        row = col.row(align=True)   
        row.prop(my_prop, "my_dens")
        row = col.row(align=True)   
        row.prop(my_prop, "my_dep")
        row.prop(my_prop, "my_dep2")
        row = col.row(align=True)  
        row.label(text="Cut Material:",icon='MATERIAL')
        row.prop(my_prop, "my_enum")
        
        mat_name="NC_Broken-Concrete"
        ng = bpy.data.materials
        if mat_name not in ng:
            row = col.row(align=True)  
            row.operator("wm.mat")
        

class DISPL_PT_PANEL(NoizyCuttPanel, bpy.types.Panel):
    bl_parent_id = "NCMAIN_PT_PANEL"
    bl_label = "Displacement"
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        my_prop = scene.my_prop    
    
        col = layout.column(align=True)        
        row = layout.row(align=True)     

        row.label(text="Noise:",icon='TEXTURE_DATA')
        row = layout.row(align=True)   
        row.prop(my_prop, "my_noiz")
        row.prop(my_prop, "my_scal")
      
        row = layout.row(align=True)  
        row = layout.row(align=True)   
        row.label(text="Texture:",icon='IMAGE_DATA')
        row = layout.row(align=True)   
        row.prop(my_prop, "my_path")
        row.operator("wm.upd",icon='FILE_REFRESH')
        row = layout.row(align=True)   
        row.prop(my_prop, "my_disp")        
        row.prop(my_prop, "my_scale2") 
        row = layout.row(align=True)          
        row.prop(my_prop, "my_rot")


class UTILS_PT_PANEL(NoizyCuttPanel, bpy.types.Panel):
    bl_parent_id = "NCMAIN_PT_PANEL"
    bl_label = "Utils"
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        my_prop = scene.my_prop    
    

        col = layout.column(align=True)        
        row = layout.row(align=True)
        row.operator("wm.wir")
        row = layout.row(align=True)
        row.operator("wm.split",icon='MOD_INSTANCE')
        row.operator("wm.orig",icon='OBJECT_ORIGIN')
        row = layout.row(align=True)
        row.operator("wm.reset")
        row.operator("wm.reset2")
        


        
        
        



# ------------------------------------------------------------------------
#    Registration
# ------------------------------------------------------------------------

classes = (
    MyProperties,
    NCMAIN_PT_PANEL,
    DISPL_PT_PANEL,
    UTILS_PT_PANEL,
    DRAW_button,
    MESHER2_button,
    BOOL_button,
    BOOL2_button,
    BOOL3_button,
    SPLIT_button,
    ORIG_button,
    UPD_button,
    WIR_button,
    CYC_button,
    MAT_button,
    RESET_button,
    RESET2_button,

)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.my_prop = PointerProperty(type=MyProperties)


def unregister():
    from bpy.utils import unregister_class
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.my_prop
    



if __name__ == "__main__":
    register()