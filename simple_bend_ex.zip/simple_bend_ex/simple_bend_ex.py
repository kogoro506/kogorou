# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
# Created by Kushiro

import math
from operator import indexOf

import bpy
import bmesh
import bmesh.utils

from mathutils import Matrix, Vector, Quaternion, Euler

import mathutils
import time
import numpy as np



from bpy.props import (
    FloatProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    FloatVectorProperty,
    StringProperty
)

from pprint import pprint
# from . import gui

import itertools
import numpy as np

import random




def line_edge(bm, p1, p2):
    v1 = bm.verts.new(p1)
    v2 = bm.verts.new(p2)
    e1 = bm.edges.new((v1, v2))
    e1.select = True
    return e1


def get_directions(vectors, n_components=2):
    vectors_norm = vectors / np.linalg.norm(vectors, axis=1, keepdims=True)
    mean_vector = np.mean(vectors_norm, axis=0)
    centered_vectors = vectors_norm - mean_vector
    covariance_matrix = np.cov(centered_vectors, rowvar=False)
    eigenvalues, eigenvectors = np.linalg.eigh(covariance_matrix)
    sorted_indices = np.argsort(eigenvalues)[::-1] 
    eigenvalues = eigenvalues[sorted_indices]
    eigenvectors = eigenvectors[:, sorted_indices]
    principal_directions = eigenvectors[:, :n_components].T 
    explained_variance = eigenvalues[:n_components]    
    return principal_directions

def get_nearest_vector(normals, axis):
    normals = np.array(normals)
    axis = np.array(axis)
    axis = axis / np.linalg.norm(axis)
    dot_products = np.dot(normals, axis)
    max_index = np.argmax(dot_products)
    return normals[max_index]



def calc_center(vs):
    vs = np.array([v.co for v in vs])
    mid_x = (np.max(vs[:, 0]) + np.min(vs[:, 0])) / 2.0
    mid_y = (np.max(vs[:, 1]) + np.min(vs[:, 1])) / 2.0
    mid_z = (np.max(vs[:, 2]) + np.min(vs[:, 2])) / 2.0
    return Vector((mid_x, mid_y, mid_z))

    # if not vs:
    #     return Vector((0, 0, 0))
    # center = Vector((0, 0, 0))
    # for v in vs:
    #     center += v.co
    # center /= len(vs)
    # return center




def get_mat(m1, m2, m3, cen):
    if m1.length == 0 or m2.length == 0 or m3.length == 0:
        return Matrix.Identity(4)            
    m = Matrix.Identity(4)        
    m[0][0:3] = m1.normalized()
    m[1][0:3] = m2.normalized()
    m[2][0:3] = m3.normalized()
    m[3][0:3] = cen.copy()
    m = m.transposed()
    return m



def get_bend(t, total_length, angle, offset, scale):
    if angle == 0:
        p = [total_length * t + offset[0], offset[1]]
        return np.array(p)
    R = total_length / angle
    R = R * scale
    phi = t * angle
    x_c = R * np.sin(phi)
    y_c = R * (1.0 - np.cos(phi))
    tx = np.cos(phi)
    ty = np.sin(phi)
    nx = -ty
    ny =  tx
    dx, dy = np.asarray(offset, dtype=float)
    x = x_c + dx * tx + dy * nx
    y = y_c + dx * ty + dy * ny 
    return np.array([x, y])




def twsting(vs, gp1, gp2, twist_angle, mat, mat2, end1, end2, off_left, off_right):
    if twist_angle == 0:
        return            

    if off_left:    
        for v1 in gp1:
            p1 = mat2 @ v1.co
            total = end1.x
            t = 1.0
            rot = Quaternion(Vector((1.0, 0, 0)), t * twist_angle / 180 * math.pi)
            v1.co = mat @ (rot @ p1)            

    if off_right:
        for v1 in gp2:
            p1 = mat2 @ v1.co
            total = abs(end2.x)
            t = 1.0
            rot = Quaternion(Vector((1.0, 0, 0)), -t * twist_angle / 180 * math.pi)
            v1.co = mat @ (rot @ p1)

    for v1 in vs:
        p1 = mat2 @ v1.co
        if p1.x >= 0:
            if off_left:
                total = end1.x
                t = p1.x / total
                rot = Quaternion(Vector((1.0, 0, 0)), t * twist_angle / 180 * math.pi)
                v1.co = mat @ (rot @ p1)
        else:
            if off_right:
                total = abs(end2.x)
                t = abs(p1.x / total)
                rot = Quaternion(Vector((1.0, 0, 0)), -t * twist_angle / 180 * math.pi)
                v1.co = mat @ (rot @ p1)



def get_grouping(vs, center, ax3):
    gp1 = set()
    gp2 = set()    
    ring = []
    for v1 in vs:
        m1 = v1.co - center
        pro1 = m1.dot(ax3)
        for e1 in v1.link_edges:
            # v2 = e1.other_vert(v1)
            for v2 in e1.verts:
                if v2.select == False:
                    if pro1 >= 0:
                        gp1.add(v2)
                    else:
                        gp2.add(v2)
                    ring.append(v2)
                    v2.select = True    
    
    while True:        
        ring2 = []
        for v1 in ring:            
            if v1 in gp1:
                polar = True
            else:
                polar = False
            for e1 in v1.link_edges:
                # v2 = e1.other_vert(v1)
                for v2 in e1.verts:
                    if v2.select == False:
                        if polar:
                            gp1.add(v2)
                        else:
                            gp2.add(v2)
                        v2.select = True
                        ring2.append(v2)
                        break
        ring = ring2
        if len(ring) == 0:
            break    

    for v in gp1:
        v.select = False
    for v in gp2:
        v.select = False

    return gp1, gp2


def get_two_ends(vs, mat, mat2):
    ps = []
    for v1 in vs:
        p1 = mat2 @ v1.co
        ps.append(p1.x)
    ps = np.array(ps)
    end1 = ps.max()
    end2 = ps.min()
    end1 = mat @ (Vector((end1, 0, 0)))
    end2 = mat @ (Vector((end2, 0, 0)))    
    return end1, end2



def bending(scale, center, ax1, ax3, vs, bend_direction, bend_angle,
             off_left, off_right, twist_angle, shift, vshift, full_SSB):
    # vsall = get_connected_face(bm, sel)
    rot = Quaternion(ax3, bend_direction / 180 * math.pi)
    ax1.rotate(rot)
    sn = ax3.cross(ax1)
    mat = get_mat(ax3, ax1, sn, center)
    mat_cen = mat @ Vector((shift, 0, 0))
    mat = get_mat(ax3, ax1, sn, mat_cen)
    mat2 = mat.inverted()

    if full_SSB:
        # end1 - origin - end2
        end1, end2 = get_two_ends(vs, mat, mat2)
        if off_left == False:        
            mat = get_mat(ax3, ax1, sn, end1)
            mat2 = mat.inverted()
        if off_right == False:
            mat = get_mat(ax3, ax1, sn, end2)
            mat2 = mat.inverted()

    ps = []
    for v1 in vs:
        m1 = v1.co - center
        pro1 = m1.dot(ax3)
        ps.append(pro1)

    ps = np.array(ps)
    end1 = ps.max()
    end2 = ps.min()
    end1 = mat2 @ (center + ax3 * end1)
    end2 = mat2 @ (center + ax3 * end2)

    bend_angle = bend_angle / 180 * math.pi

    gp1, gp2 = get_grouping(vs, center, ax3)

    twsting(vs, gp1, gp2, twist_angle, mat, mat2, end1, end2, off_left, off_right)

    if off_left:
        for v1 in gp1:                
            p1 = mat2 @ v1.co
            total = end1.x
            t = 1.0
            offset = p1 - end1
            offset = [offset.x, offset.y]
            pos = get_bend(t, total, bend_angle, offset, scale)        
            v1.co = mat @ Vector((pos[0], pos[1], p1.z+t*vshift))        

    if off_right:
        for v1 in gp2:
            p1 = mat2 @ v1.co
            total = abs(end2.x)
            t = 1.0
            offset = p1 - end2
            offset = [-1 * offset.x, offset.y]
            pos = get_bend(t, total, bend_angle, offset, scale)
            v1.co = mat @ Vector((-1 * pos[0], pos[1], p1.z-t*vshift))            

    for v1 in vs:        
        p1 = mat2 @ v1.co
        if p1.x >= 0:
            if off_left:
                total = end1.x
                if total == 0:
                    continue
                t = p1.x / total 
                offset = [0, p1.y]
                pos = get_bend(t, total, bend_angle, offset, scale)          
                v1.co = mat @ Vector((pos[0], pos[1], p1.z+t*vshift))
        else:
            if off_right:
                total = abs(end2.x)
                if total == 0:
                    continue
                t = abs(p1.x / total)
                offset = [0, p1.y]
                pos = get_bend(t, total, bend_angle, offset, scale)
                v1.co = mat @ Vector((-1 * pos[0], pos[1], p1.z-t*vshift))




def get_connected_face(bm, sel):
    bpy.ops.mesh.select_linked()
    fall = [f1 for f1 in bm.faces if f1.select]
    for f1 in fall:
        f1.select = False
    for f1 in sel:
        f1.select = True

    vsall = []
    for f1 in fall:
        for v1 in f1.verts:            
            vsall.append(v1)
    vsall = list(set(vsall))
    return vsall 


def get_topk(vectors, n_clusters=6, max_iter=100, random_state=0):
    rng = np.random.default_rng(random_state)
    n_samples = vectors.shape[0]    

    indices = rng.choice(n_samples, n_clusters, replace=False)
    centroids = vectors[indices].copy()
    
    for _ in range(max_iter):
        distances = np.sqrt(((vectors[:, None] - centroids) ** 2).sum(axis=2))        
        labels = np.argmin(distances, axis=1)
        old_centroids = centroids.copy()
        
        for k in range(n_clusters):
            if np.sum(labels == k) > 0:
                centroids[k] = np.mean(vectors[labels == k], axis=0)
        
        if np.all(old_centroids == centroids):
            break
    
    return labels, centroids


def find_top_directions(vectors, n_directions=2, n_clusters=8, random_state=0):
    vectors = np.array(vectors)
    
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    unit_vectors = vectors / norms    
    labels, centroids = get_topk(unit_vectors, n_clusters=n_clusters, random_state=random_state)
    centroids = centroids / np.linalg.norm(centroids, axis=1, keepdims=True)
    
    top_directions = np.zeros((n_clusters, 3))
    for k in range(n_clusters):
        cluster_vectors = unit_vectors[labels == k]
        if len(cluster_vectors) > 0:
            distances = np.sqrt(((cluster_vectors - centroids[k]) ** 2).sum(axis=1))            
            closest_idx = np.argmin(distances)
            top_directions[k] = cluster_vectors[closest_idx]
    
    cluster_counts = np.bincount(labels, minlength=n_clusters)    
    sorted_indices = np.argsort(-cluster_counts)
    top_directions = top_directions[sorted_indices[:n_directions]]
    top_counts = cluster_counts[sorted_indices[:n_directions]]
    
    return top_directions



class SimpleBendExOperator(bpy.types.Operator):
    """Tooltip"""
    bl_idname = "mesh.simple_bend_ex_operator"
    bl_label = "Simple Bend Ex"
    bl_options = {"REGISTER", "UNDO"}
    #, "GRAB_CURSOR", "BLOCKING"


    prop_angle: FloatProperty(
        name="Bend Angle",
        description="Bend Angle",
        default=0,
        step=20,
    )    

    prop_bend: FloatProperty(
        name="Bend Direction",
        description="Bend Direction",
        default=0,
        step=20,
    )    

    operation_mode : EnumProperty(
                #(identifier, name, description, icon, number)
        items = [('Both','Both','','',0),
                 ('Left','Left','','',1), 
                 ('Right','Right','','',2),
                 ],
        name = "Mode",
        default = 'Both')


    prop_size: FloatProperty(
        name="Bend Size",
        description="Bend Size",
        default=1.0,
        step=2,
    )        


    prop_shift: FloatProperty(
        name="Bend Shift",
        description="Bend Shift",
        default=0,
        step=0.2,
    )     


    prop_twist: FloatProperty(
        name="Twist",
        description="Twist Angle",
        default=0,
        step=20,
    )        

    prop_add90: BoolProperty(
        name="Swap Direction",
        description="Add 90 degrees to bend direction",
        default=False,
    )        


    prop_full_SSB: BoolProperty(
        name="Full SSB",
        description="Full Single Side Bend",
        default=True,
    )


    prop_show_axis: BoolProperty(
        name="Show bending axis",
        description="Show bending axis (for debug and checking)",
        default=False,
    )    

    swap_axis : EnumProperty(
                #(identifier, name, description, icon, number)
        items = [
                ('None','None','','',0),
                ('Swap X','Swap X','','',1),
                 ('Swap Y','Swap Y','','',2), 
                 ],
        name = "Swap",
        default = 'None')
    
    global_axis : EnumProperty(
                #(identifier, name, description, icon, number)
        items = [
                ('None','None','','',0),
                ('X','X','','',1),
                 ('Y','Y','','',2), 
                 ('Z','Z','','',3), 
                 ],
        name = "Use Global Axis",
        default = 'None')    
    
    
    prop_center: FloatVectorProperty(
        name="Offset",
        description="Offset the bending center",
        size=3,
        default=(0.0, 0.0, 0.0),
        subtype='XYZ',           # draws X Y Z boxes
        precision=3,             # show 3 decimal places
        step=0.1,                # arrow-key increment
    )    


    prop_avg_axis: BoolProperty(
        name="Use Average Axis",
        description="Use average axis for bending",
        default=False,
    )        


    prop_vshift: FloatProperty(
        name="Vertical Shift",
        description="Vertical Shift",
        default=0,
        step=0.2,
    )     


    def fix_direction_for_flat(self, ax):
        ax2 = []
        for p in ax:
            p = Vector(p)
            if p.length == 0:
                continue
            p.normalize()
            ax2.append(p)
        if len(ax2) == 0:
            return [Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))]
        elif len(ax2) == 1:
            main = ax2[0]
            for p in [Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))]:
                # find the vector that is orthogonal to the main vector
                if main.dot(p) < 0.1 and main.dot(p) > -0.1:
                    return [main, p, main.cross(p).normalized()]
        elif len(ax2) >= 2:
            return ax
        else:
            return [Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))]


    def free_bend(self, bm):
        sel = [f1 for f1 in bm.faces if f1.select]
        if len(sel) < 4:
            self.report({'WARNING'}, "Select at least 4 faces to bend")
            return

        axis = []
        vs = [v for v in bm.verts if v.select]
        for f1 in sel:
            area = f1.calc_area()
            sn = f1.normal * area
            axis.append(sn)

        center = calc_center(vs)

        axis = np.array(axis)
        if len(axis) < 3:
            return
        
        # vsall = get_connected_verts(vs)
        # vsall = get_connected_face(bm, sel)
        sample_size = min(8, len(axis))

        if self.prop_avg_axis:
            ax = get_directions(axis, n_components=sample_size)
        else:            
            ax = find_top_directions(axis, n_directions=sample_size, n_clusters=sample_size, random_state=0)

        ax = self.fix_direction_for_flat(ax)

        if len(ax) < 2:
            self.report({'WARNING'}, "Not enough directions to bend")
            return            
        ax = np.array(ax)
        ax1 = ax[0]
        ax1 = Vector(ax1).normalized()
        ax2 = None
        for i in range(1, len(ax)):
            p = ax[i]
            p = Vector(p).normalized()
            if p.dot(ax1) > 0.98:
                continue
            if p.dot(ax1) < -0.98:
                continue
            c1 = ax1.cross(p)
            if c1.length < 0.01:
                continue
            ax2 = p
            break
        if ax2 is None:
            self.report({'WARNING'}, "Not enough directions to bend")
            return

        # ax1 = Vector(ax[0])
        # ax2 = Vector(ax[1])
        ax1.normalize()
        ax2.normalize()
        ax3 = ax1.cross(ax2)
        ax3.normalize()

        # ax2 = get_nearest_vector(axis, ax3)
        # ax2 = ax3
        # ax2 = Vector(ax2).normalized()
        # ax2 = ax1       

        if self.operation_mode == 'Both':
            off_left = True
            off_right = True
        elif self.operation_mode == 'Left':
            off_left = True
            off_right = False
        elif self.operation_mode == 'Right':
            off_left = False
            off_right = True
        else:
            off_left = True
            off_right = True
        # ax1 = ax2.cross(ax3)

        if self.swap_axis == 'Swap X':
            ax3, ax1, ax2 = ax1, ax2, ax3
        elif self.swap_axis == 'Swap Y':
            ax3, ax1, ax2 = ax2, ax3, ax1

        if self.global_axis == 'X':
            ax3 = Vector((0, 0, 1))
            ax2 = Vector((0, 1, 0))
            ax1 = Vector((1, 0, 0))
        elif self.global_axis == 'Y':
            ax3 = Vector((1, 0, 0))
            ax2 = Vector((0, 0, 1))
            ax1 = Vector((0, 1, 0))
        elif self.global_axis == 'Z':
            ax3 = Vector((0, 1, 0))
            ax2 = Vector((1, 0, 0))
            ax1 = Vector((0, 0, 1))  

        if self.prop_center != (0.0, 0.0, 0.0):
            center += Vector(self.prop_center)    

        ax2 = ax1.cross(ax3)
        ax2.normalize()  

        if self.prop_show_axis:
            line_edge(bm, center, center + ax1 * 30.0)
            line_edge(bm, center, center + ax2 * 30.0)
            line_edge(bm, center, center + ax3 * 30.0)

        if self.prop_add90:
            swap90 = 90.0
        else:
            swap90 = 0.0

        bending(self.prop_size, center, ax1, ax3, vs, 
                self.prop_bend + swap90, self.prop_angle,
                  off_left, off_right, self.prop_twist, 
                  self.prop_shift, self.prop_vshift, self.prop_full_SSB)
        bm.normal_update()



    def draw(self, context):
        layout = self.layout        
        layout.label(text="Mode: ")
        row = layout.row(align=True)
        row.prop(self, "operation_mode", expand=True)
        layout.label(text="")

        layout.prop(self, "prop_add90")
        layout.prop(self, "prop_full_SSB")
        layout.prop(self, "prop_angle")
        layout.prop(self, "prop_bend")  
        layout.label(text="")      
        layout.prop(self, "prop_size")

        layout.label(text="")     
        layout.prop(self, "prop_shift")
        layout.prop(self, "prop_vshift")
        
        layout.label(text="")     
        layout.label(text="Twist:")
        layout.prop(self, "prop_twist")        
        layout.label(text="")     
        layout.label(text="Swap Axis:")

        row = layout.row(align=True)
        row.prop(self, "swap_axis", expand=True)   
        layout.label(text="")

        layout.label(text="Use Global Axis:")
        row = layout.row(align=True)
        # Draw the EnumProperty as buttons (expand=True for push buttons)
        row.prop(self, "global_axis", expand=True)
        layout.label(text="")

        layout.prop(self, "prop_avg_axis")
        layout.label(text="")
        layout.label(text="Offset Center:")
        layout.prop(self, "prop_center")
        layout.prop(self, "prop_show_axis")
        


    def get_bm(self):
        obj = bpy.context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        return bm

       

    def process(self, context):
        bm = self.get_bm() 
 
        self.free_bend(bm)

        obj = bpy.context.active_object                
        me = bpy.context.active_object.data
        bmesh.update_edit_mesh(me)  


    def execute(self, context):
        self.process(context)      
        return {'FINISHED'}    

    
    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        selecting = active_object is not None and active_object.type == 'MESH'        
        editing = context.mode == 'EDIT_MESH' 
        is_vert_mode, is_edge_mode, is_face_mode = context.tool_settings.mesh_select_mode
        return selecting and editing


    def invoke(self, context, event): 
        self.prop_bend = 0
        self.prop_angle = 0
        self.prop_size = 1.0
        self.prop_shift = 0
        self.prop_vshift = 0
        self.prop_add90 = False
        self.operation_mode = 'Both'
        self.swap_axis = 'None'
        self.prop_twist = 0
        self.prop_show_axis = False
        self.global_axis = 'None'
        self.prop_center = (0.0, 0.0, 0.0)
        self.prop_avg_axis = False       
        self.prop_center = (0.0, 0.0, 0.0) 
        self.prop_full_SSB = True
                
        if context.edit_object:
            self.process(context)
            return {'FINISHED'} 
        else:
            return {'CANCELLED'}



