# idTools Maya 2022+ ( python 3)

## idTools UI

Button code for idTools which should be placed on shelf or into shortcut code field, if you want use UI:

```python
from idTools import *

if __name__ == "__main__":
    try:
        wtool.deleteLater()
    except:
        pass   
     
    wtool = MainWindow()
    
    try:
        wtool.create()
        wtool.show()
    except:
        wtool.deleteLater()
```

## Quick CopyPaste shortcuts

Two part of code for copy paste shortcuts, separated by # ( comments symbol) you should use it, if want to have just shortcut without UI:

```python
# Paste button
from idTools import IdToolSetUtils
tools = IdToolSetUtils()
tools.copyPaste("i")
```

```python
# Copy button
from idTools import IdToolSetUtils
tools = IdToolSetUtils()
tools.copyPaste("c")
```